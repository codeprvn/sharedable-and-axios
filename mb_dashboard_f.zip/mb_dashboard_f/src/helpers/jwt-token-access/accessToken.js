export const setToken = (token, user)=>{
 
  localStorage.setItem('token', token)
  localStorage.setItem("authUser", JSON.stringify(user))
}

export  const accessToken = async ()=>{
  return localStorage.getItem('token')
}
  
