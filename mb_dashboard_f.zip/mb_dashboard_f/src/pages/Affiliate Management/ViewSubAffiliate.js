import { useState, useEffect } from 'react'
import { useFormik } from 'formik';
import {  Row,  Col,  Card,  CardBody,  Button,  Label,  Input,} from "reactstrap";
import IndeterminateCheckbox from '../../common/ModuleList and Hooks/IndeterminateCheckbox';
import useCheckList from '../../common/ModuleList and Hooks/CheckListHook';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { useParams, useHistory } from 'react-router-dom/cjs/react-router-dom';
import { get } from "../../helpers/api_helper"
import ErrorPopup from 'common/Popup/ErrorPopup';
import apiRoute from '../../common/ApiURL.json';

const ViewSubAffiliate = (props) => {
    const history = useHistory()
    const [formData, setFormData] = useState({
        name: '',
        userName: '',
        parentUser:'',
        mobile: '',
        emailId: '',
        panCard:'',
        creditLimit:'',
        commissionPercent:'',
        city:'',
        dob:'',
        status:'',
        address:'',
        branchName:'',
        accountNumber:'',
        IFSCode: '',
        accountName:''  
      });

      const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Affiliate Management", link: "#" },
        { title: "View Sub Affiliate", link: "#" },
      ]

  
 // Dailog variable
const {id} = useParams();
const [errorDialog, setErrorDialog] = useState(false);
const [errorMsg, setErrorMsg] = useState('');
const { checkboxData, handleChangeParent, handleChangeChild, setCheckboxData } = useCheckList([]);

  const formik = useFormik({    
    enableReinitialize: true,
    initialValues: formData,    
  });
  
  async function apiData() {
    try {
        const resp = await get(apiRoute.affiliateManagement.listSubAffiliate, { params: { id } })
        setFormData(resp.data);
        setCheckboxData([...resp?.data?.modules ]);
    } catch (error) {
      setErrorMsg(error);
        setErrorDialog(true);
    }
}

useEffect(() => {
    props.setBreadcrumbItems('View Sub Affiliate', breadcrumbItems);
    apiData()
  }, [])


  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    history.goBack();
  }
 
  return (
    <Col xl="12">
    <Card>
      <CardBody>
        <form  onSubmit={formik.handleSubmit}
        >
          <Row>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="validationTooltip01">Name:</Label>
                <Input
                  type="text" name='name'
                  className="form-control"
                  id="validationTooltip01"
                  placeholder="Enter Name"
                  value={formik.values.name}
                  onChange={formik.handleChange} readOnly
                />
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="validationTooltip02">Username:</Label>
                <Input
                  type="text" name='userName'
                  className="form-control"
                  id="validationTooltip02"
                  placeholder="Enter Username"
                  value={formik.values.userName}
                  onChange={formik.handleChange} readOnly
                />                
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="affiliateId">Parent Affiliate:</Label>
                <Input
                  type="text" name='affiliateId'
                  className="form-control"
                  id="affiliateId"
                  placeholder="Enter Username"
                  value={formik.values.affiliateId}
                  onChange={formik.handleChange} readOnly
                />                
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="validationTooltipUsername">Telephone:</Label>
                
                  <Input
                    type="text" name='mobile'
                    className="form-control"
                    id="validationTooltipUsername"
                    placeholder="Enter MobileNo"
                    value={formik.values.mobile}
                  onChange={formik.handleChange} readOnly
                  />
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="validationTooltip03">Email:</Label>
                <Input
                  type="email" name='emailId'
                  className="form-control"
                  id="validationTooltip03"
                  placeholder="Enter Email"
                  value={formik.values.emailId}
                  onChange={formik.handleChange} readOnly
                /> 
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="panCard">Pan Card:</Label>
                <Input
                  type="text" name='panCard'
                  className="form-control"
                  id="panCard"
                  placeholder="XXX123"
                  value={formik.values.panCard}
                  onChange={formik.handleChange} readOnly
                />
              </div>
            </Col>
            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="branchName">Branch Name:</Label>
                                    <Input type="text" name='branchName'
                                        className="form-control"
                                        id="branchName"
                                        placeholder="Enter Branch Name"
                                        value={formik.values.branchName}
                                        onChange={formik.handleChange} readOnly
                                    />
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="accountName">Account Name:</Label>
                                    <Input type="text" name='accountName'
                                        className="form-control"
                                        id="accountName"
                                        placeholder="Enter Account Name"
                                        value={formik.values.accountName}
                                        onChange={formik.handleChange} readOnly
                                    />  
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="accountNumber">Account number:</Label>
                                    <Input type="text" name='accountNumber'
                                        className="form-control"
                                        id="accountNumber"
                                        placeholder="Enter Account Number"
                                        value={formik.values.accountNumber}
                                        onChange={formik.handleChange} readOnly
                                    />
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="IFSCode">IFSC:</Label>
                                    <Input type="text" name='IFSCode'
                                        className="form-control"
                                        id="IFSCode"
                                        placeholder="Enter IFSC"
                                        value={formik.values.IFSCode}
                                        onChange={formik.handleChange} readOnly
                                    />
                                </div>
                            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="creditLimit">Credit Limit:</Label>
                <Input
                  type="number" name='creditLimit'
                  className="form-control"
                  id="creditLimit"
                  placeholder="1000"
                  value={formik.values.creditLimit}
                  onChange={formik.handleChange} readOnly
                /> 
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="comissionPercent">Commission Percent:</Label>
                <Input
                  type="number" name='commissionPercent'
                  className="form-control"
                  id="comissionPercent"
                  placeholder="1000"
                  value={formik.values.commissionPercent}
                  onChange={formik.handleChange} readOnly
                />
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="city">City:</Label>
                <Input
                  type="text" name='city'
                  className="form-control"
                  id="city"
                  placeholder="New Delhi"
                  value={formik.values.city}
                  onChange={formik.handleChange} readOnly
                />
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="dateOfBirth">Date Of Birth:</Label>
                <Input
                  type="date" name='dob'
                  className="form-control"
                  id="dateOfBirth"
                  value={formik.values.dob}
                  onChange={formik.handleChange} readOnly
                />
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="statusId">Sub affiliate Status:</Label>
                <select className="form-select form-control"
                        value={formik.values.status}
                        name='status'
                         id="statusId"
                        onChange={formik.handleChange} disabled>
                       <option defaultValue hidden>Select Sub affiliate Status</option>
                        <option>Active</option>
                      <option>Blocked</option>
                    </select>
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="address">Address:</Label>
                <Input type='text' className="form-control"
                        value={formik.values.address}
                        name='address'
                        id='address'
                        rows="1"
                        onChange={formik.handleChange} readOnly />
                </div>
            </Col>
          </Row>
          <div className="container-fluid text-center bg-dark text-white fs-3 p-2 my-10"><span> Modules / Sub-Modules </span></div>
          
          {checkboxData?.map((checkbox, index) => (           
            <IndeterminateCheckbox
              key={index}
              index={index}
              label={checkbox.name}
              checked={checkbox.allTicked}
              onChange={handleChangeParent}
              children={checkbox.subModules}
              isDisabled={true}
              childrenHandle={(childIndex) => handleChangeChild(index, childIndex)}
            />
          ))}

          <div className='d-flex flex-row gap-5 justify-content-center text-center mt-5'>
          <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Back</Button>
          </div>
        </form>
      </CardBody>
    </Card>
  
    {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}            
  </Col>
  )
}

export default connect(null, { setBreadcrumbItems })(ViewSubAffiliate)