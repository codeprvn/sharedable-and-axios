import { useState } from 'react';

const useCheckList = (initialState) => {
  const [checkboxData, setCheckboxDataState] = useState(initialState);

  const handleChangeParent = (key) => {
    //  logic for handling parent checkbox
    setCheckboxData((prevCheckboxData) =>
    prevCheckboxData.map((obj, index) => {
      if (index === key) {
        const updatedSubModule = obj.subModules?.map((sub) => ({
          ...sub,
          status: !obj.allTicked,
          // subModules: sub.subModules?.map((child) => ({
          //   ...child,
          //   status: !obj.allTicked,
          // })),
        }));
        return { ...obj, allTicked: !obj.allTicked, subModules: updatedSubModule };
      }
      return obj;
    })
  );
  };

  const isAllFieldsCompleted = (submodules) => {
    return submodules.every((sub) => sub.status === true);
  };

  const handleChangeChild = (parentIndex, childIndex) => {
    // logic for handling child checkbox
    setCheckboxData((prevCheckboxData) =>
    prevCheckboxData.map((obj, index) => {
      if (index === parentIndex) {
        const updatedSubModule = obj.subModules?.map((sub, subIndex) =>
          subIndex === childIndex
            ? {
                ...sub,
                status: !sub.status,
                // subModules: sub.subModules?.map((child) => ({
                //   ...child,
                //   status: !sub.status,
                // })),
              }
            : sub
        );
        const allFieldsCompleted = isAllFieldsCompleted(updatedSubModule);

        return { ...obj, subModules: updatedSubModule, allTicked: allFieldsCompleted };
      }
      return obj;
    })
  );
  };

  const setCheckboxData = (newData) => {
    setCheckboxDataState(newData);
  };

  return { checkboxData, handleChangeParent, handleChangeChild, setCheckboxData };
};

export default useCheckList;