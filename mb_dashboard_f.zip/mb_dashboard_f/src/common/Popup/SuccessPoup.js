import React, {useState, useEffect} from 'react'
import Dialog from '@mui/material/Dialog';
import { Button} from "reactstrap";
import './success.scss'

const SuccessPoup = ({ successMsg, confirmBtnText,  onConfirm, closeTimeout  }) => {

  const [shouldClose, setShouldClose] = useState(false);
  useEffect(() => {
    let timer;

    if (closeTimeout && closeTimeout > 0) {
      timer = setTimeout(() => {
        setShouldClose(true);
      }, closeTimeout);
    }

    return () => {
      clearTimeout(timer);
    };
  }, [closeTimeout]);

  const handleClose = () => {
    setShouldClose(false);
    onConfirm();
  };


  return (
    <Dialog open={!shouldClose} onClose={handleClose} aria-labelledby="alert-dialog-title" className='oueter' aria-describedby="alert-dialog-description">
    <div className='popUpContainer'>
    <div className="symbolSucess">&#10003;</div>
    <h2 className="text">{successMsg}</h2>
    <div className='closeBtn'>
    <Button type="button" color="danger" className="waves-effect waves-light"
            onClick={ handleClose} >
            {confirmBtnText || 'Close'}
          </Button>
          </div>
    </div>
</Dialog>
  )
}

export default SuccessPoup