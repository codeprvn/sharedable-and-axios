import React from "react"
import { Redirect } from "react-router-dom"

// Profile
import UserProfile from "../pages/Authentication/user-profile"

// Authentication related pages
import Login from "../pages/Authentication/Login"
import Logout from "../pages/Authentication/Logout"
import Register from "../pages/Authentication/Register"
import ForgetPwd from "../pages/Authentication/ForgetPassword"

//  // Inner Authentication
import Login1 from "../pages/AuthenticationInner/Login"
import Register1 from "../pages/AuthenticationInner/Register"
import Recoverpw from "../pages/AuthenticationInner/Recoverpw"
import LockScreen from "../pages/AuthenticationInner/auth-lock-screen"

// Dashboard
import Dashboard from "../pages/Dashboard/index"

//Extra Pages
import PagesTimeline from "../pages/Extra Pages/pages-timeline";
import PagesInvoice from "../pages/Extra Pages/pages-invoice";
import PagesDirectory from "../pages/Extra Pages/pages-directory";
import PagesBlank from "../pages/Extra Pages/pages-blank";
import Pages404 from "../pages/Extra Pages/pages-404";
import Pages500 from "../pages/Extra Pages/pages-500";
import CreateUser from "pages/UserManagement/Create-user"
import CreateAffiliate from "pages/Affiliate Management/Create-Affiliate"
import CreateSubAffiliate from "pages/Affiliate Management/Create-Sub-Affiliate"
import CreatePlayer from "pages/Player Management/Create-Player"
import ListUser from "pages/UserManagement/ListUser"
import ListAffiliates from "pages/Affiliate Management/ListAffiliates"
import ListSubAffiliates from "pages/Affiliate Management/ListSubAffiliates"
import ListPlayer from "pages/Player Management/ListPlayer"
import DailyLogInReport from "pages/Player Management/DailyLogInReport"
import EditUser from "pages/UserManagement/EditUser"
import ViewUser from "pages/UserManagement/ViewUser"
import EditAffiliate from "pages/Affiliate Management/EditAffiliate"
import ViewAffiliate from "pages/Affiliate Management/ViewAffiliate"
import EditSubAffiliate from "pages/Affiliate Management/EditSubAffiliate"
import ViewSubAffiliate from "pages/Affiliate Management/ViewSubAffiliate"
import EditPlayer from "pages/Player Management/EditPlayer"
import ViewPlayer from "pages/Player Management/ViewPlayer"
import GameList from "pages/Game Management/GameList"
import AddNewGame from "pages/Game Management/AddNewGame"
import EditGame from "pages/Game Management/EditGame"
import TransferAmount from "pages/Chips Management/TransferAmount"
import TransferHistory from "pages/Chips Management/TransferHistory"
import ViewTransactionHistory from "pages/Chips Management/ViewTransactionHistory"
import GenerateBonusCode from "pages/Bonus_Management/GenerateBonusCode"
import BonusCodeList from "pages/Bonus_Management/BonusCodeList"
import BounsHistory from "pages/Bonus_Management/BounsHistory"
import EditBonusCode from "pages/Bonus_Management/EditBonusCode"
import AddPaymentGateway from "pages/Payment_Gateway/AddPaymentGateway"
import ListPaymentGateway from "pages/Payment_Gateway/ListPaymentGateway"
import EditPaymentGateway from "pages/Payment_Gateway/EditPaymentGateway"

const userRoutes = [
  { path: "/", component: Dashboard },

  //userManagement routes
  // { path: "/userManagement", component: IconMaterialdesign },
  {path: "/create-user", component:CreateUser},
  {path: '/edit-user/:id', component: EditUser},
  {path: '/view-user/:id', component: ViewUser},
  {path:'/create-affiliate', component:CreateAffiliate},
  {path:'/edit-affiliate/:id', component:EditAffiliate},
  {path:'/view-affiliate/:id', component:ViewAffiliate},
  {path:'/create-subAffiliate', component:CreateSubAffiliate},
  {path:'/edit-subaffiliate/:id', component: EditSubAffiliate},
  {path:'/view-subaffiliate/:id', component: ViewSubAffiliate},
  {path:'/create-player', component:CreatePlayer},
  {path:'/edit-player/:id', component:EditPlayer},
  {path:'/view-player/:id', component: ViewPlayer},
  {path:'/list-user', component:ListUser},
  {path:'/list-affiliates', component:ListAffiliates},
  {path:'/list-subaffiliates', component:ListSubAffiliates},
  {path:'/list-subaffiliates/:parentUser', component:ListSubAffiliates},
  {path:'/list-player', component: ListPlayer},
  {path:'/list-player/:parentUser', component: ListPlayer},
  {path:'/daily-login-report', component: DailyLogInReport},
  
  //Game management routes
  {path:'/game-list', component:GameList},
  {path:'/add-new-game', component:AddNewGame},
  {path:'/edit-game/:id', component:EditGame},
  {path:'/view-game/:id', component:EditGame},
  

  //Chips Management
  {path:'/tranfer-amount', component: TransferAmount},
  {path:'/transfer-history', component: TransferHistory},
  // {path:'/transfer-history-affiliatessubaffiliates', component: TransferHistoryAffSubaff},
  {path:'/view-txn-history', component: ViewTransactionHistory},

  // Bonus Code Management
  {path:'/generate-bonus-code', component: GenerateBonusCode},
  {path:'/bonus-code-list', component:BonusCodeList },
  {path:'/bonus-history', component:BounsHistory },
  {path: '/edit-bonus/:id', component:EditBonusCode},

  {path:'/add-paymentGateway', component:AddPaymentGateway},
  {path:'/list-paymentGateway', component:ListPaymentGateway},
  {path:'/edit-paymentGateway/:id', component:EditPaymentGateway},

 //profile
  { path: "/bonusManagement", component: UserProfile },



  // // //Charts
  // { path: "/masterTransactionLogs", component: ChartsAppex },
  // { path: "/charts-chartist", component: ChartsChartist },
  // { path: "/charts-chartjs", component: ChartsJs },
  // { path: "/charts-knob", component: ChartsKnob },
  // { path: "/charts-c3", component: ChartsC3 },
  // { path: "/sparkline-charts", component: ChartsSparkLine },



 

  // //Extra Pages
  { path: "/pages-timeline", component: PagesTimeline },
  { path: "/pages-invoice", component: PagesInvoice },
  { path: "/pages-directory", component: PagesDirectory },
  { path: "/pages-blank", component: PagesBlank },

  // this route should be at the end of all other routes
  // { path: "/", exact: true, component: () => <Redirect to="/" /> },
]

const authRoutes = [
  { path: "/logout", component: Logout },
  { path: "/login", component: Login },
  { path: "/forgot-password", component: ForgetPwd },
  { path: "/register", component: Register },

  { path: "/pages-404", component: Pages404 },
  { path: "/pages-500", component: Pages500 },

  // Authentication Inner
  { path: "/pages-login", component: Login1 },
  { path: "/pages-register", component: Register1 },
  { path: "/page-recoverpw", component: Recoverpw },
  { path: "/auth-lock-screen", component: LockScreen },
]

export { userRoutes, authRoutes }