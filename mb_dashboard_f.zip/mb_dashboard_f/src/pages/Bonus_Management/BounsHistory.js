import React, { useEffect } from 'react';
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import SharedTable from 'common/table/SharedTable';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import ErrorPopup from 'common/Popup/ErrorPopup';
import { dateFormate, validFiled } from 'common/SharedFunction';
import apiRoute from '../../common/ApiURL.json';
import { useListTableHook } from 'common/ModuleList and Hooks/ListTableHook';

const BounsHistory = (props) => {
  const breadcrumbItems = [
    { title: "Arcade", link: "/" },
    { title: "Bonus Management", link: "#" },
    { title: "Bonus History", link: "#" },
  ]

  const columns = [
    { id: 'position', label: 'No' },
    { id: 'userName', label: 'Username' },
    { id: 'codeName', label: 'Bonus Code' },
    { id: 'bonusType', label: 'Bonus Type' },
    { id: 'amountDeposited', label: 'Amount Deposited' },
    { id: 'rcbChips', label: 'Chips in RCB' },
    { id: 'ucbClaimed', label: 'UCB Claimed' },
    { id: 'ucbExpired', label: 'UCB Expired' },
    { id: 'ucbRecieved', label: 'UCB Recieved' },
    { id: 'ucbExpiryDate', label: 'UCB Expiry Date',format: (value) => dateFormate(value) },
    { id: 'ucbAvailable', label: 'UCB Available' },
    { id: 'lockedAmount', label: 'Locked Amount' },
    { id: 'instantBonus', label: 'Instant Bonus' },
    { id: 'totalBonusCredited', label: 'Total Bonus Credited' },
    { id: 'usedAt', label: 'Used At', format: (value) => dateFormate(value) },
    { id: 'expiredStatus', label: 'Expired Status' }
  ];

  const actionButton = [{ name: 'Edit' }];

  const formData = { userName: ''}

  const { rows, totalPage, page, errorDialog, setErrorDialog, setPage, errorMsg, handlePagination, apiData, onSubmit } = useListTableHook(
    apiRoute.bonusManagement.bonusHistory, formData);

  //Table pagination 
  const handleChangePage = (event, newPage) => {
    let skip = newPage * 20;
    handlePagination(newPage, skip, 20)
  };

  const actionHandler = (name, id) => {
    const paramId = id.id
    if (name === 'Edit') {
      history.push(`/edit-player/${paramId}`)
    }
  }

  const formik = useFormik({
    initialValues: formData,
    validateOnMount:true,
    validationSchema: Yup.object({
      userName: Yup.string().required('Username required'),
    }),
    onSubmit: onSubmit

  });

  // reset form
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    setPage(0);
    apiData();
  }

  useEffect(() => {
    props.setBreadcrumbItems('Bonus History', breadcrumbItems);
    apiData();
  }, [])

  return (
    <Col xl="12">
      <Card>
        <CardBody>
          <form onSubmit={formik.handleSubmit}>
            <Row>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="userName">Username:</Label>
                  <Input
                    type="text" name='userName'
                    className="form-control"
                    id="userName"
                    placeholder="Enter Username"
                    value={formik.values.userName}
                    onChange={formik.handleChange}
                    onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                  />
                  {formik.errors.userName ? (
                    <small className="text-danger">{formik.errors.userName}</small>
                  ) : null}
                </div>
              </Col>            

            </Row>

            <div className='d-flex flex-row gap-5 justify-content-center text-center my-3'>
              <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={validFiled(formik.values)}>Submit</Button>
              <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
              {/* <Button type="button" outline color="success" className="waves-effect waves-light">CSV</Button> */}
            </div>
          </form>

          <SharedTable columns={columns} rows={rows} page={page} totalPage={totalPage} handleChangePage={handleChangePage} actionButton={actionButton} actionHandler={actionHandler}  />
        </CardBody>
      </Card>
      {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
    </Col>
  )
}

export default connect(null, { setBreadcrumbItems }) (BounsHistory)