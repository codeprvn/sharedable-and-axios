import React from 'react'
// import Table from '@mui/material/Table';
// import TableBody from '@mui/material/TableBody';
// import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
// import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
// import TableRow from '@mui/material/TableRow';
import './sharedTable.scss'
import { Button } from "reactstrap";

const SharedTable = ({ columns, rows, page, handleChangePage, totalPage, actionButton, actionHandler }) => {
  return (
    <>
      <TableContainer sx={{ maxHeight: 'auto' }}>
        <table className="table table-bordered dataTable" aria-label="sticky table">
          <thead >
            <tr >
              {columns && columns.map((column, id) => (
                <th key={column.id}
                >
                  {column.label}
                </th>
              ))}
              {actionButton?.length > 0 && <th >Action</th>}
            </tr>
          </thead>
          <tbody>
            {rows && rows.map((row, index) => {
              return (
                <tr key={row.id || index} >
                  {columns.map((column) => {
                    const value = row[column.id];
                    return (
                      <td key={column.id} >
                        {column.format
                          ? column.format(value)
                          : (column.Changes ? column.Changes(row) : value)}
                      </td>
                    );
                  })}
                  {actionButton?.length > 0 && <td>
                    <div className='actionGrid'>

                      {/* below line is static for enable disable  */}
                      {/* {actionButton.map((btn) => btn.name==='Disable'? (<button className={row['isActive'] ?'actionButton danger' :'actionButton '} key={btn.name} onClick={() => actionHandler(row['isActive'] ? btn.name : 'Enable', row)}>{row['isActive'] ? btn.name : 'Enable'}</button>) :(<button className='actionButton' key={btn.name} onClick={() => actionHandler(btn.name, row)}>{btn.name}</button>))} */}

                      {/* by this we can create button accordingly */}
                      {actionButton.map(btn => btn.format ? btn.format(btn.name, row) : (<Button outline color="primary" className="waves-effect waves-light" key={btn.name} onClick={() => actionHandler(btn.name, row)}>{btn.name}</Button>))}
                    </div></td>}
                </tr>
              );
            })}
          </tbody>
        </table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[-1]}
        component="div"
        count={totalPage}
        rowsPerPage={20}
        page={page}
        onPageChange={handleChangePage}
        showFirstButton={true}
        showLastButton={true}
      // labelDisplayedRows={({ from, to, count }) => `Items per page:20 ${from}-${to} of ${count}`}
      />
    </>
  )
}

export default SharedTable