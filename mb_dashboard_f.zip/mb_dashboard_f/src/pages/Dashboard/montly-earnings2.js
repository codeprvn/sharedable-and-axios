import React, {useState} from 'react';
import { Row, Col, Card, CardBody } from "reactstrap";
import ReactApexChart from 'react-apexcharts';

 function MonthlyEarnings (props) {
    const month = [...props.monthRevenue.map(item=> item.month)]
    const totalEarning = [...props.monthRevenue.map(item=> item.totalAmount)]
    const TotalRevenue = props.monthRevenue.reduce((acu, item)=> acu + item.totalAmount,0)
    const totalTranscation = props.monthRevenue.reduce((acu, item)=> acu + item.count,0)

     const state  = {
            options: {
                colors: ['#28bbe3', '#28bbe3'],
                chart: {
                    stacked: true,
                    toolbar: {
                        show: false,
                    },
                },
                dataLabels: {
                    enabled: false,
                },
                plotOptions: {
                    bar: {
                        columnWidth: '70%',
                    },
                },
                grid: {
                    borderColor: '#f8f8fa',
                    row: {
                        colors: ['transparent', 'transparent'], // takes an array which will be repeated on columns
                        opacity: 0.5
                    },
                },

                xaxis: {
                    categories: month,
                    labels: {
                        formatter: function (val) {
                            return val
                        },
                    },
                    axisBorder: {
                        show: false
                    },
                    axisTicks: {
                        show: false
                    }
                },
                yaxis: {
                    title: {
                        text: []
                    },
                },
                tooltip: {
                    y: {
                        formatter: function (val) {
                            return val
                        }
                    }
                },
                fill: {
                    opacity: 1
                },

                legend: {
                    show: false,
                    position: 'top',
                    horizontalAlign: 'left',
                    offsetX: 40
                }
            },
            series: [{
                name: 'Total Amount',
                data: totalEarning
            }],
        }
    
    
        return (
            <React.Fragment>
                <Card>
                    <CardBody>
                        <h4 className="card-title mb-4">MONTHLY REVENUE</h4>
                        <Row className="text-center mt-4">
                            <Col xs="6">
                                <h5 className="font-size-20">$ {TotalRevenue}</h5>
                                <p className="text-muted">Total Revenue</p>
                            </Col>
                            <Col xs="6">
                                <h5 className="font-size-20">{totalTranscation}</h5>
                                <p className="text-muted">Total Transactions</p>
                            </Col>
                        </Row>

                        <div id="morris-bar-stacked" className="morris-charts morris-charts-height" dir="ltr">
                            <ReactApexChart options={state.options} series={state.series} type="bar" height="290" />
                        </div>
                    </CardBody>
                </Card>
            </React.Fragment>
        );
        }

export default MonthlyEarnings;