import React, {useEffect, useState} from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, Select } from "reactstrap";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import apiRoute from '../../common/ApiURL.json';
import {removeEmpty, inputDate } from 'common/SharedFunction';
import { MultiSelect } from "react-multi-select-component";
import { get, put } from 'helpers/api_helper';
import { useParams, useHistory } from 'react-router-dom/cjs/react-router-dom';


const EditBonusCode = (props) => {
    const {id} = useParams();
    const history = useHistory();
 // breadcurms title
 const breadcrumbItems = [
    { title: "Arcade", link: "/" },
    { title: "Bonus Management", link: "#" },
    { title: "Edit Bonus Code", link: "#" },
]
const [formData, setFormData]  = useState({
    bonusCodeType: '',
    codeName: '',
    bonusAmount: '',
    minAmount: '',
    maxAmount: '',
    bonusPercent: '',
    instantBonus: '',
    rcbPercent: '',
    ucbPercent: '',
    expiryDate: '',
    description: '',
    status: '',
    showOnWebsiteAndApp: '',
    ucbExpiry: '',
    amountLockedPercent: '',
})

 // Dailog variable
 const [successDialog, setSuccessDialog] = useState(false);
 const [successMsg, setSuccessMsg] = useState('');
 const [errorDialog, setErrorDialog] = useState(false);
 const [errorMsg, setErrorMsg] = useState('');
 const [playerList, setPlayerList] = useState([])
 const [selectedPlayer, setSelectedPlayer] = useState([]);

 const formik = useFormik({
    initialValues: formData,
    enableReinitialize: true,
    validationSchema: Yup.object({
        bonusCodeType: Yup.string().required('Required Field'),
        codeName: Yup.string().required('Required Field').min(3, 'Minimum 3 characters required').max(20, 'Max 20 characters Allowed'),
        bonusAmount: Yup.number().optional(),
        minAmount: Yup.number().optional().max(Yup.ref('maxAmount'), "Can't be Greater than Max Amout"),
        maxAmount:  Yup.number().optional().min(Yup.ref('minAmount'), "Can't be smaller than Min Amout"),
        bonusPercent: Yup.number().when('bonusCodeType', (bonusCodeType, schema) => {
            return bonusCodeType[0] !== 'Sign Up Bonus' ? schema.required('Required Field').min(0, 'Min % should be 0').max(100, 'Max % should be 100') : schema
          }),
        instantBonus: Yup.number().optional().min(0, 'Min % should be 0'),
        rcbPercent:  Yup.number().optional().min(0, 'Min % should be 0').max(100, 'Max % should be 100'),
        ucbPercent: Yup.number().optional().min(0, 'Min % should be 0').max(100, 'Max % should be 100'),
        expiryDate: Yup.date().required('Required Field'),
        description:  Yup.string().optional(),
        status: Yup.string().required('Required Field'),
        showOnWebsiteAndApp: Yup.boolean().optional(),
        ucbExpiry:  Yup.number().when('bonusCodeType', (bonusCodeType, schema) => {
            return bonusCodeType[0] !== 'Sign Up Bonus' ? schema.required('Required Field').min(0, 'Min value should be 0'): schema }),
        amountLockedPercent: Yup.number().optional().min(0, 'Min % should be 0').max(100, 'Max % should be 100'),
      }),
    onSubmit: async (values)=>{
      try {
        const  validFor = selectedPlayer.map(item => item.value)
        const formValue = removeEmpty(values)
        const newObject = {
    bonusCodeType: formValue?.bonusCodeType,
    codeName: formValue?.codeName,
    bonusAmount: formValue?.bonusAmount,
    minAmount: formValue?.minAmount,
    maxAmount: formValue?.maxAmount,
    bonusPercent: formValue?.bonusPercent,
    instantBonus: formValue?.instantBonus,
    rcbPercent: formValue?.rcbPercent,
    ucbPercent: formValue?.ucbPercent,
    expiryDate: formValue?.expiryDate,
    description: formValue?.description,
    status: formValue?.status,
    showOnWebsiteAndApp: formValue?.showOnWebsiteAndApp,
    ucbExpiry: formValue?.ucbExpiry,
    amountLockedPercent: formValue?.amountLockedPercent, }
      const resp = await put(`${apiRoute.bonusManagement.updateBonusCode}/${id}`, { ...newObject, validFor })
      setSuccessMsg(resp?.message)
      setSuccessDialog(true)
  } catch (error) {
      setErrorMsg(error);
      setErrorDialog(true);
  }}
  });
  
  //form reset
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
  }
  
  async function getBonusListPlayer (){
      try{
          const resp = await get(apiRoute.bonusManagement.listPlayersForBonus)
          setPlayerList(resp.players.map((item=> ({label: item, value: item}))))
      }catch(error){
  
      }
  }
  
  async function getBonusDetails (){
    try{
        const resp = await get(apiRoute.bonusManagement.bonusCodeList,{ params: { id } })
        const afterRemove = removeEmpty(resp.bonusCode)
        setFormData((pre)=>({...pre, ...afterRemove, ['expiryDate']: inputDate(resp?.bonusCode?.expiryDate)}))
        if (resp?.bonusCode?.validFor.length >=1)  setSelectedPlayer(resp?.bonusCode?.validFor?.map(item => ({label: item, value: item})))
       
    }catch(error){

    }
}  
    useEffect(() => {
      props.setBreadcrumbItems('Edit Bonus Code', breadcrumbItems);
      getBonusListPlayer();
     getBonusDetails()

  }, []) 

  return (
    <Col xl="12">
    <Card>
        <CardBody>
            <form onSubmit={formik.handleSubmit}
            >
                <Row>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="bonusCodeType1">Type of bonus:</Label>
                            <select className="form-select form-control"
                                value={formik.values.bonusCodeType}
                                name='bonusCodeType' id='bonusCodeType1'
                                onChange={formik.handleChange} disabled >
                                <option defaultValue hidden>Select Player Status</option>
                                        <optgroup label="Sign Up">
                                        <option value="Sign Up Bonus">Sign Up Bonus</option>
                                        </optgroup>
                                        <optgroup label="Deposit">
                                        <option value="First Time Deposit Bonus">First Time Deposit Bonus</option>
                                        <option value="Normal Deposit Bonus">Normal Deposit Bonus</option>
                                        </optgroup>
                                        <optgroup label="Special">
                                        <option value="Special Bonus">Custom Bonus</option>
                                        <option value="Weekly">Weekly Bonus</option>
                                        <option value="Monthly">Monthly Bonus</option>
                                        <option value="Loosing">Loosing Bonus</option>
                                        </optgroup>
                            </select>
                            {formik.errors.bonusCodeType ? (
                                <small className="text-danger">{formik.errors.bonusCodeType}</small>
                            ) : null}
                        </div>
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="codeName">Bonus Code:</Label>
                            <Input
                                type="text" name='codeName'
                                className="form-control"
                                id="codeName"
                                placeholder="Enter Bonus Code"
                                value={formik.values.codeName} readOnly
                                onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                                onChange={(event) =>  formik.setFieldValue('codeName', event.target.value.toUpperCase())}
                            />
                            {formik.errors.codeName ? (
                                <small className="text-danger">{formik.errors.codeName}</small>
                            ) : null}
                        </div>
                    </Col>
                   {formik.values.bonusCodeType === 'Sign Up Bonus' && <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="bonusAmount">Bonus Amount:</Label>
                            <input 
                                type="number" name='bonusAmount'
                                className="form-control"s
                                id="bonusAmount"
                                placeholder="Enter Bonus Amount"
                                value={formik.values.bonusAmount}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.bonusAmount ? (
                                <small className="text-danger">{formik.errors.bonusAmount}</small>
                            ) : null}
                        </div>
                    </Col>}

                    {formik.values.bonusCodeType === 'Special Bonus' && <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="description">Valid For :</Label>
                            <MultiSelect options={playerList} value={selectedPlayer} onChange={setSelectedPlayer}
                          className="select2-selection"  />
                             
                            {formik.errors.description ? (
                                <small className="text-danger">{formik.errors.description}</small>
                            ) : null}
                        </div>
                    </Col>
                    }
                    {formik.values.bonusCodeType !== 'Sign Up Bonus' && <><Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="minAmount">Min Amount:</Label>
                            <input 
                                type="number" name='minAmount'
                                className="form-control"
                                id="minAmount"
                                placeholder="Enter Min Amount"
                                value={formik.values.minAmount}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.minAmount ? (
                                <small className="text-danger">{formik.errors.minAmount}</small>
                            ) : null}
                        </div>
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="maxAmount">Max Amount:</Label>
                            <Input
                                type="number" name='maxAmount'
                                className="form-control"
                                id="maxAmount"
                                placeholder="Enter Max Amount"
                                value={formik.values.maxAmount}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.maxAmount ? (
                                <small className="text-danger">{formik.errors.maxAmount}</small>
                            ) : null}
                        </div>
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="bonusPercent">Bonus %:</Label>
                            <Input
                                type="number" name='bonusPercent'
                                className="form-control"
                                id="bonusPercent"
                                placeholder="Enter Bonus Percent"
                                value={formik.values.bonusPercent}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.bonusPercent ? (
                                <small className="text-danger">{formik.errors.bonusPercent}</small>
                            ) : null}
                        </div>
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="instantBonus">Instant Bonus %:</Label>
                            <Input
                                type="number" name='instantBonus'
                                className="form-control"
                                id="instantBonus"
                                placeholder="Enter Instant Bonus Percent"
                                value={formik.values.instantBonus}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.instantBonus ? (
                                <small className="text-danger">{formik.errors.instantBonus}</small>
                            ) : null}
                        </div>
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="amountLockedPercent">Amount Locked %:</Label>
                            <Input
                                type="number" name='amountLockedPercent'
                                className="form-control"
                                id="amountLockedPercent"
                                placeholder="Enter Amount Locked Percent"
                                value={formik.values.amountLockedPercent}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.amountLockedPercent ? (
                                <small className="text-danger">{formik.errors.amountLockedPercent}</small>
                            ) : null}
                        </div>
                    </Col></>}
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="rcbPercent">RCB %:</Label>
                            <Input
                                type="number" name='rcbPercent'
                                className="form-control"
                                id="rcbPercent"
                                placeholder="Enter RCB Percent"
                                value={formik.values.rcbPercent}
                                onChange={(event) => {const rcbPercent = parseInt(event.target.value, 10) ||0;
                                  const ucbPercent = 100 - rcbPercent ;                           
                                  formik.setFieldValue('rcbPercent', rcbPercent);
                                  formik.setFieldValue('ucbPercent', ucbPercent);}}
                            />
                            {formik.errors.rcbPercent ? (
                                <small className="text-danger">{formik.errors.rcbPercent}</small>
                            ) : null}
                        </div>
                        {}
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="ucbPercent">UCB %:</Label>
                            <Input
                                type="number" name='ucbPercent'
                                className="form-control"
                                id="ucbPercent"
                                placeholder="Enter RCB Percent"
                                value={formik.values.ucbPercent}
                                onChange={(event) => {
                                  const ucbPercent = parseInt(event.target.value, 10) ||0;
                                  const rcbPercent = 100 - ucbPercent                            
                                  formik.setFieldValue('ucbPercent', ucbPercent);
                                  formik.setFieldValue('rcbPercent', rcbPercent);
                                }}
                            />
                            {formik.errors.ucbPercent ? (
                                <small className="text-danger">{formik.errors.ucbPercent}</small>
                            ) : null}
                        </div>
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="ucbExpiry">UCB valid till:</Label>
                            <Input
                                type="number" name='ucbExpiry'
                                className="form-control"
                                id="ucbExpiry"
                                placeholder="Give Values In Days"
                                value={formik.values.ucbExpiry}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.ucbExpiry ? (
                                <small className="text-danger">{formik.errors.ucbExpiry}</small>
                            ) : null}
                        </div>
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="expiryDate">Coupon Expiry:</Label>
                            <Input
                                type="date" name='expiryDate'
                                className="form-control"
                                id="expiryDate"
                                value={formik.values.expiryDate}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.expiryDate ? (
                                <small className="text-danger">{formik.errors.expiryDate}</small>
                            ) : null}
                        </div>
                    </Col>
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="description">Bonus Description:</Label>
                            <Input
                                type="textarea" name='description'
                                className="form-control"
                                id="description"  rows="1"
                                placeholder="Enter Description"
                                value={formik.values.description}
                                onChange={formik.handleChange}
                            />
                            {formik.errors.description ? (
                                <small className="text-danger">{formik.errors.description}</small>
                            ) : null}
                        </div>
                    </Col>                            
                    
                    <Col md="4">
                        <div className="mb-3 position-relative">
                            <Label htmlFor="status1">Status:</Label>
                            <select className="form-select form-control"
                                value={formik.values.status}
                                name='status' id='status1'
                                onChange={formik.handleChange}>
                                <option defaultValue hidden>Select Player Status</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                            {formik.errors.status ? (
                                <small className="text-danger">{formik.errors.status}</small>
                            ) : null}
                        </div>
                    </Col>
                    {formik.values.bonusCodeType !== 'Sign Up Bonus' && <Col className='align-self-center' md="4" >
        <div className='form-check'>
        <input className="form-check-input" type="checkbox" value={formik.values.showOnWebsiteAndApp} id="showOnWebsiteAndApp"
                onChange={formik.handleChange} />
              <label className="form-check-label" htmlFor="showOnWebsiteAndApp">Show On Website and App</label>
              </div>
        </Col>}
                </Row>
                
                <div className='d-flex flex-row gap-5 justify-content-center text-center mt-5'>
                    <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>
                    <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
                </div>
            </form>
        </CardBody>
    </Card>
    {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false); 
    history.push(`/bonus-code-list`)}} />}
    {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
</Col>
  )
}

export default connect(null, { setBreadcrumbItems }) (EditBonusCode)