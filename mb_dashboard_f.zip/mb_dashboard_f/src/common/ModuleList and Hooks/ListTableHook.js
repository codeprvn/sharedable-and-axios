
import { useState, useRef } from 'react'
import {get} from "../../helpers/api_helper"
import { removeEmpty } from 'common/SharedFunction';



export const useListTableHook = (apiUrl, initialState) => {
  const [rows, setRows] = useState([]);
  const [totalPage, setTotalPage] = useState(0);
  const [page, setPage] = useState(0);
  const [errorDialog, setErrorDialog] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const isfilter = useRef('');
  const forFilter = useRef('');

  const handlePagination = async (newPage,skip, limit) => {
    setPage(newPage)  
    try {
      const params = isfilter.current === 'YES' ? { ...forFilter.current, skip, limit } : { skip, limit };
      const resp = await get(apiUrl, { params });
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData);
    } catch (error) {
      setErrorMsg(error);
      setErrorDialog(true);
    }
  };

  const apiData = async () => {
    try {
      const resp = await get(apiUrl, { params: { skip: 0, limit: 20 } });
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData);
      isfilter.current = resp?.isFiltered;
    } catch (error) {
      setErrorMsg(error);
      setErrorDialog(true);
    }
  };

  const onSubmit = async (values) => {
    const formData = removeEmpty({ ...values });
    formData.startDate ?formData.startDate= new Date(formData.startDate).getTime() : null;
    formData.endDate ?formData.endDate= new Date(formData.endDate).getTime() : null;
    try {
      const resp = await get(apiUrl, { params: { ...formData, skip: 0, limit: 20 } });
      setPage(0);
      setRows([...resp?.data]);
      forFilter.current = { ...formData };
      isfilter.current = resp?.isFiltered;
      setTotalPage(resp?.totalData);
    } catch (error) {
      setErrorMsg(error);
      setErrorDialog(true);
    }
  };

  return { rows, totalPage, page, errorDialog,setErrorDialog ,errorMsg, handlePagination, apiData,setErrorMsg ,setPage,onSubmit };
};
