import { useState, useEffect } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import {  Row,  Col,  Card,  CardBody,  Button,  Label,  Input,} from "reactstrap";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { useParams, useHistory } from 'react-router-dom/cjs/react-router-dom';
import { get, put } from 'helpers/api_helper';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import apiRoute from '../../common/ApiURL.json';

const EditPlayer = (props) => {
const history = useHistory();
  const {id} = useParams();
  
  const [formData, setFormData] = useState({
    firstName:'',
    lastName: '',
    userName: '',
    dob:'',
    parentUserName:'',
    mobile: '',
    emailId: '',
    rakeBack:'',
    isOrganic:'',
    status:'',
    reasonForBan:'',
    isTopUpAllowed:'',
    topupLimit:'',
    isKYCVerified:false,
    byPassIp:false,
      });

      const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Player Management", link: "#" },
        { title: "Edit Player", link: "#" },
      ]

   
    
 // Dailog variable
 const [successDialog, setSuccessDialog] = useState(false);
 const [successMsg, setSuccessMsg] = useState('');
 const [errorDialog, setErrorDialog] = useState(false);
 const [errorMsg, setErrorMsg] = useState('');

    const formik = useFormik({
        initialValues: formData,
        enableReinitialize: true,
        validationSchema: Yup.object({
          firstName:Yup.string().required('First Name required'),
          lastName: Yup.string().required('Last Name required'),
          userName: Yup.string().required('Username required').max(20, 'Max 20 digit required').min(3, 'Min 3 digit required'),
          parentUserName:Yup.string().required('Affiliate Username is mandatory'),
          mobile:  Yup.string().required('Mobile No required'),
          emailId: Yup.string().email('Enter a valid Email').required('Email required'),          
          dob:Yup.date().required('DOB required'),
          rakeBack:Yup.number().required('Rack Back required').min(0,'Negative value not allowed'),
          status:Yup.string().required('Status required'),
          isOrganic:Yup.string().required('Player Type required'),
          reasonForBan:Yup.string().when('status', (status, schema) => {
            return status[0] === 'true' ? schema.required(' Reason required') : schema
          }),
          isTopUpAllowed:Yup.string().required('Allow topup required'),
          topupLimit:Yup.number().when('isTopUpAllowed', (isTopUpAllowed, schema) => {
            return isTopUpAllowed[0] === 'true' ? schema.required().min(0,'Negative value not allowed') : schema
          }),
          // isKYCVerified:Yup.boolean(),
          // byPassIp:Yup.boolean(),
        }),
        onSubmit: async values => {
          try {
            const newObject = { firstName: values.firstName,
              lastName: values.lastName,
              userName: values.userName,
              dob: values.dob,
              parentUserName: values.parentUserName,
              mobile: values.mobile,
              emailId: values.emailId,
              rakeBack: values.rakeBack,
              isOrganic: values.isOrganic,
              status: values.status,
              reasonForBan: values.reasonForBan,
              isTopUpAllowed: values.isTopUpAllowed,
              topupLimit: values.topupLimit,
              isKYCVerified: values.isKYCVerified,
              byPassIp: values.byPassIp};
            
            const resp = await put(`${apiRoute.playerManagement.updatePlayer}/${id}`, newObject)
            setSuccessMsg(resp?.message)
            setSuccessDialog(true)
        } catch (error) {
          setErrorMsg(error);
            setErrorDialog(true);
        }
        },
      });
      
      const formReset = (event) => {
        event.preventDefault();
        history.goBack();
      }

      async function apiData() {
        try {
          // const abortController = new AbortController()
            const resp = await get(apiRoute.playerManagement.listPlayer, { params: { id } })
            setFormData({ ...resp.data });
        } catch (error) {
            setErrorMsg(error);
            setErrorDialog(true);
        }
    }
     
    useEffect(() => {
      props.setBreadcrumbItems('Edit Player', breadcrumbItems);
      apiData();
    }, [])  

      return (
        <Col xl="12">
        <Card>
          <CardBody>
            <form  onSubmit={formik.handleSubmit}
            >
              <Row>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="firstName">First Name:</Label>
                    <Input
                      type="text" name='firstName'
                      className="form-control"
                      id="firstName"
                      placeholder="Enter First Name"
                      value={formik.values.firstName}
                      onChange={formik.handleChange}
                    />
                    {formik.errors.firstName ? (
                  <small className="text-danger">{formik.errors.firstName}</small>
                ) : null}
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="lastName">Last Name:</Label>
                    <Input
                      type="text" name='lastName'
                      className="form-control"
                      id="lastName"
                      placeholder="Enter First Name"
                      value={formik.values.lastName}
                      onChange={formik.handleChange}
                    />
                    {formik.errors.lastName ? (
                  <small className="text-danger">{formik.errors.lastName}</small>
                ) : null}
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="userName">Username:</Label>
                    <Input
                      type="text" name='userName'
                      className="form-control"
                      id="userName"
                      placeholder="Enter Username"
                      value={formik.values.userName}
                      onChange={formik.handleChange} readOnly
                    />
                     {formik.errors.userName ? (
                  <small className="text-danger">{formik.errors.userName}</small>
                ) : null}                
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="dob">DOB:</Label>
                    <Input
                      type="date" name='dob'
                      className="form-control"
                      id="dob"
                      value={formik.values.dob}
                      onChange={formik.handleChange}
                    max={ new Date().toISOString().slice(0, 10)}
                    />
                    {formik.errors.dob ? (
                  <small className="text-danger">{formik.errors.dob}</small>
                ) : null} 
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="parentUserName">Affiliate Username:</Label>
                    <Input
                      type="text" name='parentUserName'
                      className="form-control"
                      id="parentUserName"
                      placeholder="Enter Affiliate Username"
                      value={formik.values.parentUserName}
                      onChange={formik.handleChange}
                    />
                     {formik.errors.parentUserName ? (
                  <small className="text-danger">{formik.errors.parentUserName}</small>
                ) : null}                
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="email">Email:</Label>
                    <Input
                      type="email" name='emailId'
                      className="form-control"
                      id="email"
                      placeholder="Enter Email"
                      value={formik.values.emailId}
                      onChange={formik.handleChange}
                    />
                    {formik.errors.emailId ? (
                  <small className="text-danger">{formik.errors.emailId}</small>
                ) : null} 
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="mobileNo">Telephone:</Label>                    
                    <PhoneInput
                     disableDialCodeAndPrefix={true}
                     disableFormatting={true}
                     inputClassName='form-control'
                      defaultCountry="in" name='mobile'
                        id="mobile"
                        placeholder="Enter Mobile"
                        value={formik.values.mobile} 
                      onChange={(data, meta) => {
                        formik.setFieldValue('mobile',meta.inputValue);
                      }}/>
                     {formik.errors.mobile ? (
                  <small className="text-danger">{formik.errors.mobile}</small>
                ) : null} 
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="rakeBack">Rakeback:</Label>
                    <Input
                      type="number" name='rakeBack'
                      className="form-control"
                      id="rakeBack"
                      placeholder="0"
                      value={formik.values.rakeBack}
                      onChange={formik.handleChange}
                    />
                    {formik.errors.rakeBack ? (
                  <small className="text-danger">{formik.errors.rakeBack}</small>
                ) : null} 
                  </div>
                </Col>                             
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="playerTypeId">Player Type:</Label>
                    <select className="form-select form-control"
                            value={formik.values.isOrganic}
                            name='isOrganic'
                             id="playerTypeId"
                            onChange={formik.handleChange}>
                           <option defaultValue hidden>Select a value</option>
                            <option value={true}>Organic</option>
                          <option value={false}>InOrganic</option>
                        </select>
                        {formik.errors.isOrganic ? (
                  <small className="text-danger">{formik.errors.isOrganic}</small>
                ) : null}
                  </div>
                </Col>
              </Row>
              <Row> 
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="statusId">Player Status:</Label>
                    <select className="form-select form-control"
                            value={formik.values.status}
                            name='status'
                             id="statusId"
                            onChange={formik.handleChange}>
                           <option defaultValue hidden>Select a value</option>
                            <option value={'Active'}>Active</option>
                          <option value={'Blocked'}>Blocked</option>
                        </select>
                        {formik.errors.status ? (
                  <small className="text-danger">{formik.errors.status}</small>
                ) : null}
                  </div>
                </Col>
                {formik.values.status === 'Blocked' && <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="reasonForBanId">Reason:</Label>
                    <Input
                      type="text" name='reasonForBan'
                      className="form-control"
                      id="reasonForBanId"
                      placeholder="Cheater"
                      value={formik.values.reasonForBan}
                      onChange={formik.handleChange} />                           
                        {formik.errors.reasonForBan ? (
                  <small className="text-danger">{formik.errors.reasonForBan}</small>
                ) : null}
                  </div>
                </Col>}

                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="isTopUpAllowedId">Allow Topup:</Label>
                    <select className="form-select form-control"
                            value={formik.values.isTopUpAllowed}
                            name='isTopUpAllowed'
                             id="isTopUpAllowedId"
                            onChange={formik.handleChange}>
                           <option defaultValue hidden>Select a value</option>
                            <option value={true}>Yes</option>
                          <option value={false}>No</option>
                        </select>
                        {formik.errors.isTopUpAllowed ? (
                  <small className="text-danger">{formik.errors.isTopUpAllowed}</small>
                ) : null}
                  </div>
                </Col>
               { formik.values.isTopUpAllowed.toString() =='true' && <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="topupLimit">Topup Limit:</Label>
                    <Input type='number' className="form-control"
                            value={formik.values.topupLimit}
                            name='topupLimit'
                            id='topupLimit'
                            placeholder='5000'
                            onChange={formik.handleChange} />
                        {formik.errors.topupLimit ? (
                  <small className="text-danger">{formik.errors.topupLimit}</small>
                ) : null}
                  </div>
                </Col>}
                <Col md="4" className='align-self-center'>
                <div className='form-check'>
                <input className="form-check-input" type="checkbox" checked={formik.values.byPassIp} id="byPassIp"
                        onChange={(e) => formik.setFieldValue('byPassIp', e.target.checked)} />
                      <label className="form-check-label" htmlFor="byPassIp">Validate IP</label>
                      </div>
                </Col>
                <Col md="4" className='align-self-center'>
                <div className='form-check'>
                <input className="form-check-input" type="checkbox" checked={formik.values.isKYCVerified} id="isKYCVerified"
                        onChange={(e) => formik.setFieldValue('isKYCVerified', e.target.checked)}  />
                      <label className="form-check-label" htmlFor="isKYCVerified">KYC Verified</label>
                </div>
                </Col>
              </Row>
                  
              <div className='d-flex flex-row gap-5 justify-content-center text-center mt-5'>
              <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>
              <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Back</Button>
              </div>
            </form>
          </CardBody>
        </Card>
        {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false); history.push(`/list-player`) }} />}
        {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}           
      </Col>
      )
}

export default connect(null, { setBreadcrumbItems })(EditPlayer)