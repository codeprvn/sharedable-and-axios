import React, {useEffect, useState} from 'react';
import {  Row,  Col,  Card,  CardBody,  Button,  Label,  Input,} from "reactstrap";
import { connect } from "react-redux";
import { setBreadcrumbItems } from "../../store/actions";
import { useFormik } from 'formik';
import * as Yup from "yup";
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import apiRoute from '../../common/ApiURL.json';
import { put, get } from 'helpers/api_helper';
import { useHistory, useParams } from 'react-router-dom/cjs/react-router-dom.min';

const EditPaymentGateway = (props) => {
    const {push, goBack} = useHistory();
    const {id} = useParams();
    const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Payment Gateway", link: "#" },
        { title: "Edit Payment Gateway", link: "#" },
      ]

      const [paymentData, setPaymentData] = useState({
        name:'',
        apiKey:'',
        merchantId:'',
        clientId:'',
        returnUrl:'',
        status:''
    });

     // Dailog variable
 const [successDialog, setSuccessDialog ] = useState(false);
 const [successMsg, setSuccessMsg] = useState('');
 const [errorDialog, setErrorDialog ] = useState(false);
 const [errorMsg, setErrorMsg] = useState('');
    
    const formik = useFormik({
        initialValues: paymentData,
        enableReinitialize: true,
        validationSchema: Yup.object({
        name: Yup.string().required('Required field'),
        apiKey: Yup.string().required('Required field'),
        merchantId: Yup.string().required('Required field'),
        clientId: Yup.string().required('Required field'),
        returnUrl: Yup.string().required('Required field'),
        status: Yup.string().required('Required field')
        }),
        onSubmit: async values => {
          let newFormData ={
            name:values.name,
        apiKey:values.apiKey,
        merchantId:values.merchantId,
        clientId:values.clientId,
        returnUrl:values.returnUrl,
        status:values.status
          }
            try {
              const resp = await put(apiRoute.paymentGateway.updatePayment+'/'+id, { ...newFormData})
              setSuccessMsg(resp?.message);
              setSuccessDialog(true);       
      
          } catch (error) {
              setErrorMsg(error);
              setErrorDialog(true);
          } 
          },
    })

    async function apiData(){
      try{
        const resp = await get(`${apiRoute.paymentGateway.listPayment}`,{ params: { id } });
        setPaymentData({ ...resp.data });
        
      }catch(error){
        setErrorMsg(error);
        setErrorDialog(true);
      }
    }

    const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    goBack();
  }
   
  useEffect(() => {
    props.setBreadcrumbItems('Edit Payment Gateway', breadcrumbItems);
    apiData();
  },[])

  return (
    <Col xl="12">
    <Card>
      <CardBody>
        <form  onSubmit={formik.handleSubmit}
        >
          <Row>
          <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="name">Payment Gateway Name:</Label>
                <Input
                  type="text" name='name'
                  className="form-control"
                  id="name"
                  placeholder="Enter Merchant Id"
                  value={formik.values.name}
                  onChange={formik.handleChange}
                />
                    {formik.errors.name ? (
              <small className="text-danger">{formik.errors.name}</small>
            ) : null}
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="apiKey">Api Key:</Label>
                <Input
                  type="text" name='apiKey'
                  className="form-control"
                  id="apiKey"
                  placeholder="Enter API Key"
                  value={formik.values.apiKey}
                  onChange={formik.handleChange}
                />
                    {formik.errors.apiKey ? (
              <small className="text-danger">{formik.errors.apiKey}</small>
            ) : null}
              </div>
            </Col>

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="merchantId">Merchant Id:</Label>
                <Input
                  type="text" name='merchantId'
                  className="form-control"
                  id="merchantId"
                  placeholder="Enter Merchant Id"
                  value={formik.values.merchantId}
                  onChange={formik.handleChange}
                />
                    {formik.errors.merchantId ? (
              <small className="text-danger">{formik.errors.merchantId}</small>
            ) : null}
              </div>
            </Col>

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="clientId">Client Id:</Label>
                <Input
                  type="text" name='clientId'
                  className="form-control"
                  id="clientId"
                  placeholder="Enter Client Id"
                  value={formik.values.clientId}
                  onChange={formik.handleChange}
                />
                    {formik.errors.clientId ? (
              <small className="text-danger">{formik.errors.clientId}</small>
            ) : null}
              </div>
            </Col>

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="returnUrl">Return Url:</Label>
                <Input
                  type="text" name='returnUrl'
                  className="form-control"
                  id="returnUrl"
                  placeholder="Enter Return Url"
                  value={formik.values.returnUrl}
                  onChange={formik.handleChange}
                />
                    {formik.errors.returnUrl ? (
              <small className="text-danger">{formik.errors.returnUrl}</small>
            ) : null}
              </div>
            </Col>
            
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="statusId">Status:</Label>
                 <select className="form-select form-control" name='status'
                  id="statusId"
                  value={formik.values.status}
                  onChange={formik.handleChange}>
                     <option defaultValue hidden>Select a value</option>
                      <option value={'Active'}>Active</option>
                      <option value={'InActive'}>Inactive</option>
                  </select> 
                  {formik.errors.status ? (
              <small className="text-danger">{formik.errors.status}</small>
            ) : null}                
              </div>
            </Col>
            </Row>

          <div className='d-flex flex-row gap-5 justify-content-center text-center mt-3'>
          <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>
          <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
          </div>
        </form>
      </CardBody>
    </Card>
    {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false); push('/list-paymentGateway') }} />}
            {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}           
  </Col>
    
  )
}
export default connect(null, { setBreadcrumbItems })(EditPaymentGateway) 