import { useState, useEffect, useRef } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import SharedTable from 'common/table/SharedTable';
import { useHistory } from "react-router-dom";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { get } from "../../helpers/api_helper"
import { removeEmpty, dateFormate, mobileMask, validFiled } from 'common/SharedFunction';
import ErrorPopup from 'common/Popup/ErrorPopup';
import apiRoute from '../../common/ApiURL.json';

const DailyLogInReport = (props) => {

    // breadcurms title
  const breadcrumbItems = [
    { title: "Arcade", link: "/" },
    { title: "Player Management", link: "#" },
    { title: "Daily Login Reports", link: "#" },
  ]

 // for defalut data list and set breadcrumbs
useEffect(() => {
props.setBreadcrumbItems('Daily Login Reports', breadcrumbItems);
apiData();
}, []);
  
  // form initial form data
    const formData = {userName: '', startDate:'', endDate:'',}

    // State veriable
  const [rows, setRows] = useState([]);
  const [totalPage, setTotalPage] = useState(0);
  const [page, setPage] = useState(0);
  const [errorDialog, setErrorDialog] = useState(false)
  const [errorMsg, setErrorMsg] = useState('');
  const isfilter = useRef('');
  const forFilter = useRef('');
  const history = useHistory();

  // Table colums and formate
  const columns = [
    { id: 'position', label: 'No' },
    { id: 'firstName', label: 'Full Name', Changes:(value)=>`${value.firstName} ${value.lastName}` },
    { id: 'userName', label: 'Username' },
    { id: 'device', label: 'Device' },
    { id: 'ipAddress', label: 'IP Address' },
    { id: 'mobile', label:'Mobile', format:(value)=> mobileMask(value)},
    { id: 'emailId', label:'Email'},
    { id: 'loginTime', label: 'Login Time', format:(value)=> dateFormate(value)},
  ];

     //Table pagination 
  const handleChangePage = async (event, newPage) => {
    setPage(newPage);
    let skip = newPage * 20;
    if (isfilter.current === 'YES') {
      const resp = await get(apiRoute.playerManagement.dailyLoginReport, { params: { ...forFilter.current, skip: skip, limit: 20 } })
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData);
    }
    else {
      const data = await get(apiRoute.playerManagement.dailyLoginReport, { params: { skip: skip, limit: 20 } })
      setRows([...data?.data]);
      setTotalPage(data?.totalData);
    }
  };

  const apiData = async () => {
    try {
      const resp = await get(apiRoute.playerManagement.dailyLoginReport, { params: { skip: 0, limit: 20 } })
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData)
      isfilter.current = resp?.isFiltered;
    } catch (error) {
      setErrorMsg(error);
      setErrorDialog(true);
    }
  }


    const formik = useFormik({
        initialValues: formData,
        validationSchema: Yup.object({
        
          // userName: Yup.string().required('Username required'),
          // startDate: Yup.date().required('Start Date required'),
          // endDate: Yup.date().required('End Date required')
        }),
        onSubmit: async values => {
          const formData = removeEmpty({ ...values }) 
          formData.startDate = formData.startDate ? new Date( formData.startDate ).getTime() : null
          formData.endDate = formData.endDate ? new Date( formData.endDate ).getTime() :null
          try {
            const resp = await get(apiRoute.playerManagement.dailyLoginReport, { params: { ...formData, skip: 0, limit: 20 } })
            setPage(0);
            setTotalPage(resp?.totalData)
            setRows([...resp?.data]);
            forFilter.current = { ...formData }
            isfilter.current = resp?.data?.isFiltered;
    
          } catch (error) {
            setErrorMsg(error);
            setErrorDialog(true);
          }
        },
      });
      
      // reset form
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    setPage(0);
    apiData();
  }   

  return (
    <Col xl="12">
    <Card>
      <CardBody>
        <form  onSubmit={formik.handleSubmit}>
          <Row>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="userName">Username:</Label>
                <Input
                  type="text" name='userName'
                  className="form-control"
                  id="userName"
                  placeholder="Enter Username"
                  value={formik.values.userName}
                  onChange={formik.handleChange}
                  onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                />
                 {formik.errors.userName ? (
              <small className="text-danger">{formik.errors.userName}</small>
            ) : null}                
              </div>
            </Col>
            
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="start">Start Date:</Label>
                <Input
                  type="date" name='startDate'
                  className="form-control"
                  id="start"
                  value={formik.values.startDate}
                  onChange={formik.handleChange}
                  max={ new Date().toISOString().slice(0, 10)}
                />
                {formik.errors.startDate ? (
              <small className="text-danger">{formik.errors.startDate}</small>
            ) : null}               
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="end">End Date:</Label>
                <Input
                  type="date" name='endDate'
                  className="form-control"
                  id="end"
                  value={formik.values.endDate}
                  onChange={formik.handleChange}
                  min={formik.values.startDate}
                    max={ new Date().toISOString().slice(0, 10)}
                /> 
                {formik.errors.endDate ? (
              <small className="text-danger">{formik.errors.endDate}</small>
            ) : null}              
              </div>
            </Col>

          </Row><div className='d-flex flex-row gap-5 justify-content-center text-center mb-3'>
          <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={validFiled(formik.values)}>Submit</Button>
          <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
          {/* <Button type="button" outline color="success"  className="waves-effect waves-light">CSV</Button> */}
          </div>
        </form>

        <SharedTable columns={columns} rows={rows} page={page} totalPage={totalPage} handleChangePage={handleChangePage} />
      </CardBody>
    </Card>

    {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}            
  </Col>
  )
}

export default connect(null, { setBreadcrumbItems })(DailyLogInReport)