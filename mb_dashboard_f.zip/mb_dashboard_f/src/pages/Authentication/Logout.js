import PropTypes from 'prop-types'
import React, { useEffect } from "react"
import { connect } from "react-redux"
import { withRouter, useHistory } from "react-router-dom"

import { logoutUser } from "../../store/actions"

const Logout = props => {
  const history = useHistory()
  useEffect(() => {
    props.logoutUser(props.history)
    // history.push('/login');
  })

  return <></>
}

Logout.propTypes = {
  history: PropTypes.object,
  logoutUser: PropTypes.func
}

export default withRouter(connect(null, { logoutUser })(Logout))
