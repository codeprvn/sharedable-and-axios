import PropTypes from 'prop-types'
import React,{useContext, useEffect} from "react"
import { useState } from 'react';
import ErrorPopup from 'common/Popup/ErrorPopup';
import { useFormik } from 'formik'
import * as Yup from "yup";
import apiRoute from '../../common/ApiURL.json';
import { ModuleListContext } from 'common/context/moduleListContext';

//return by me
import { post, get } from 'helpers/api_helper';
import { setToken } from 'helpers/jwt-token-access/accessToken';

import { Row, Col, CardBody, Card, Alert, Container } from "reactstrap"

// Redux
import { connect } from "react-redux"
import { withRouter, Link } from "react-router-dom"


// actions
import { loginUser, apiError } from "../../store/actions"

// import images
import logoLightPng from "../../assets/images/logo-light.png"
import logoDark from "../../assets/images/Arcade.png"

const Login = props => {
  const { moduleList, setModuleList } = useContext(ModuleListContext)
  const [errorDialog, setErrorDialog] = useState(false)
  const [errorMsg, setErrorMsg] = useState('');

  const [formData, setFormData] = useState({
    userName: '',
    password: '',
    remberMe:''
})

async function fetchData() {
  try {    
    const resp = await get(apiRoute.navModuleList);
    setModuleList([...resp]);
    return { success: true }
  } catch (error) {
    // setErrorDialog(true);
    throw new Error(error)
  }
}

const formik = useFormik({
  initialValues: formData,
  enableReinitialize: true,
  validationSchema: Yup.object({
      
      userName: Yup.string().required('Username required'),
      password: Yup.string().required('Password required').matches(/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&*!])[A-Za-z\d@#$%^&*!]+$/, 'One uppercase, one numeric, and one special character required').min(8, 'Password must contain at least 8 characters'),
        }),
  onSubmit: async values => {
    const submitData = {...values}
    delete submitData.remberMe
      try{
        let data = await post(apiRoute.login, {...submitData})
      if(data.success){
        setToken(data.access_Token, data.user)
        if(formik.values.remberMe){
          localStorage.setItem('RemberMe', JSON.stringify(values));
        }else{
          localStorage.removeItem('RemberMe');
        }

       let res = await fetchData();
       if(res?.success){
        props.history.push('/');
       }
      }
      }catch (error){
        setErrorMsg(error);
        setErrorDialog(true);
      }
  },
});

useEffect(()=>{
    const localDate = JSON.parse(localStorage.getItem('RemberMe'))
    if(localDate?.remberMe){
      setFormData((pre)=> ({...pre, ...localDate}))
    }    
},[])
 
  return (
    <React.Fragment>
      <div className="account-pages my-5 pt-sm-5">
        <Container>
          <Row className="justify-content-center">
            <Col md={8} lg={6} xl={5}>
              <Card className="overflow-hidden">
                <CardBody className="pt-0">
                  <h3 className="text-center mt-5 mb-4">
                    <Link to="/" className="d-block auth-logo">
                      <img src={logoDark} alt="" height="30" className="auth-logo-dark" />
                      <img src={logoLightPng} alt="" height="30" className="auth-logo-light" />
                    </Link>
                  </h3>
                  <div className="p-3">
                    <h4 className="text-muted font-size-18 mb-1 text-center">Welcome Back !</h4>
                    <p className="text-muted text-center">Sign in to continue to Arcade.</p>
                    <form onSubmit={formik.handleSubmit}
                      className="form-horizontal mt-4" >

                      <div className="mb-3">
                        <input
                          type="text" name='userName'
                          className="form-control"
                          id="validationTooltip02"
                          placeholder="Enter Username"
                          onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                          value={formik.values.userName}
                          onChange={formik.handleChange}
                          onFocus={formik.handleBlur}
                        />
                        {formik.errors.userName && formik.touched.userName ? (
                                        <small className="text-danger">{formik.errors.userName}</small>
                                    ) : null}
                      </div>

                      <div className="mb-3">
                        <input
                          type="password" name='password'
                          className="form-control"
                          id="validationTooltip03"
                          placeholder="Enter Password"
                          value={formik.values.password}
                          onChange={formik.handleChange}
                          onFocus={formik.handleBlur}
                      />
                      {formik.errors.password && formik.touched.password ? (
                          <small className="text-danger">{formik.errors.password}</small>
                      ) : null}
                      </div>

                      <div className="mb-3 row mt-4">
                        <div className="col-6">
                          <div className="form-check">
                            <input
                              type="checkbox"
                              checked={formik.values.remberMe}
                              onChange={(e) => formik.setFieldValue('remberMe', e.target.checked)} 
                              className="form-check-input"
                              id="customControlInline"
                            />
                            <label
                              className="form-check-label"
                              htmlFor="customControlInline"
                            >
                              Remember me
                            </label>
                          </div>
                        </div>
                        <div className="col-6 text-end">
                          <button className="btn btn-primary w-md waves-effect waves-light" type="submit">Log In</button>
                        </div>
                      </div>
                      <div className="form-group mb-0 row">
                        <div className="col-12 mt-4">
                          <Link to="/forgot-password" className="text-muted"><i className="mdi mdi-lock"></i> Forgot your password?</Link>
                        </div>
                      </div>

                    </form>
                  </div>
                </CardBody>
              </Card>
             
            </Col>
          </Row>
          {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
        </Container>
      </div>
    </React.Fragment>
  )
}

const mapStateToProps = state => {
  const { error } = state.Login
  return { error }
}

export default withRouter(
  connect(mapStateToProps, { loginUser, apiError })(Login)
)

Login.propTypes = {
  error: PropTypes.any,
  history: PropTypes.object,
  loginUser: PropTypes.func,
}