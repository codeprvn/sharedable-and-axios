import React, { useEffect } from 'react';
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import SharedTable from 'common/table/SharedTable';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import ErrorPopup from 'common/Popup/ErrorPopup';
import { dateFormate, validFiled } from 'common/SharedFunction';
import apiRoute from '../../common/ApiURL.json';
import { useListTableHook } from 'common/ModuleList and Hooks/ListTableHook';

const TransferHistory = (props) => {
  const breadcrumbItems = [
    { title: "Arcade", link: "/" },
    { title: "Chips Management", link: "#" },
    { title: "Transfer History", link: "#" },
  ]

  const columns = [
    { id: 'position', label: 'No' },
    { id: 'transferTo', label: 'Transfer To' },
    { id: 'createdAt', label: 'Transfer Date', format: (value) => dateFormate(value) },
    { id: 'amount', label: 'Number Of Chips' },
    { id: 'gstAmount', label: 'GST' },
    { id: 'transactionType', label: 'Transaction Type' },
    { id: 'tagDescription', label: 'Comment' },
    { id: 'transferBy', label: 'Transfer By' },
  ];

  const formData = { transferTo: '', startDate: '', endDate: '', transferBy:'', transactionType:'' }

  const { rows, totalPage, page, errorDialog, setErrorDialog, setPage, errorMsg, handlePagination, apiData, onSubmit } = useListTableHook(
    apiRoute.chipsManagement.tranferHistory, formData);

  //Table pagination 
  const handleChangePage = (event, newPage) => {    
    let skip = newPage * 20;
    handlePagination(newPage,skip, 20)
  };

  const formik = useFormik({
    initialValues: formData,
    validateOnMount:true,
    validationSchema: Yup.object({
    }),
    onSubmit: onSubmit

  });

  // reset form
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    setPage(0);
    apiData();
  }

  useEffect(() => {
    props.setBreadcrumbItems('Transfer History', breadcrumbItems);
    apiData();
  }, [])

  return (
    <Col xl="12">
      <Card>
        <CardBody>
          <form onSubmit={formik.handleSubmit}>
            <Row>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="transferTo">Username:</Label>
                  <Input
                    type="text" name='transferTo'
                    className="form-control"
                    id="transferTo"
                    placeholder="Enter Transfer To"
                    value={formik.values.transferTo}
                    onChange={formik.handleChange}
                    onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                  />
                  {formik.errors.transferTo ? (
                    <small className="text-danger">{formik.errors.transferTo}</small>
                  ) : null}
                </div>
              </Col>

              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="transferBy">Transfer By:</Label>
                  <Input
                    type="text" name='transferBy'
                    className="form-control"
                    id="transferBy"
                    placeholder="Enter Transfer To"
                    value={formik.values.transferBy}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.transferBy ? (
                    <small className="text-danger">{formik.errors.transferBy}</small>
                  ) : null}
                </div>
              </Col>

              <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="transactionTypeId">Transaction Type:</Label>
                    <select className="form-select form-control"
                            value={formik.values.transactionType}
                            name='transactionType'
                             id="transactionTypeId"
                            onChange={formik.handleChange}>
                           <option defaultValue hidden>Select a value</option>
                            <option value={'RC'}>RC</option>
                          <option value={'RCB'}>RCB</option>
                        </select>
                        {formik.errors.transactionType ? (
                  <small className="text-danger">{formik.errors.transactionType}</small>
                ) : null}
                  </div>
                </Col>

              <Col md="6">
                <div className="mb-3 position-relative">
                  <Label htmlFor="start">Start Date:</Label>
                  <Input
                    type="date" name='startDate'
                    className="form-control"
                    id="start"
                    value={formik.values.startDate}
                    onChange={formik.handleChange}
                    max={ new Date().toISOString().slice(0, 10)}
                  />
                  {formik.errors.startDate ? (
                    <small className="text-danger">{formik.errors.startDate}</small>
                  ) : null}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-3 position-relative">
                  <Label htmlFor="end">End Date:</Label>
                  <Input
                    type="date" name='endDate'
                    className="form-control"
                    id="end"
                    value={formik.values.endDate}
                    onChange={formik.handleChange}
                    min={formik.values.startDate}
                    max={ new Date().toISOString().slice(0, 10)}
                  />
                  {formik.errors.endDate ? (
                    <small className="text-danger">{formik.errors.endDate}</small>
                  ) : null}
                </div>
              </Col>

            </Row><div className='d-flex flex-row gap-5 justify-content-center text-center my-3'>
              <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={validFiled(formik.values)}>Submit</Button>
              <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
              {/* <Button type="button" outline color="success" className="waves-effect waves-light">CSV</Button> */}
            </div>
          </form>

          <SharedTable columns={columns} rows={rows} page={page} totalPage={totalPage} handleChangePage={handleChangePage} />
        </CardBody>
      </Card>
      {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
    </Col>
  )
}

export default connect(null, { setBreadcrumbItems })(TransferHistory)