import { useState, useEffect } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import {  Row,  Col,  Card,  CardBody,  Button,  Label,  Input,} from "reactstrap";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import { post } from 'helpers/api_helper';
import apiRoute from '../../common/ApiURL.json';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';

const TransferAmount = (props) => {
  const history = useHistory();
    const formData = {
        userType : '',
        transferTo:'',
        amount:'',
        transactionType:'RC',
        tagDescription:''
      }

      const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Chips Management", link: "#" },
        { title: "Transfer Amount", link: "#" },
      ]

      // Dailog variable
    const [successDialog, setSuccessDialog] = useState(false);
    const [successMsg, setSuccessMsg] = useState('');
    const [errorDialog, setErrorDialog] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');

   
  useEffect(() => {
    props.setBreadcrumbItems('Transfer Amount', breadcrumbItems)
  })



    const formik = useFormik({
        initialValues: formData,
        validateOnMount:true,
        validationSchema: Yup.object({
          userType: Yup.string().required('User type required'),
          transferTo: Yup.string().required('Username required'),          
          amount:Yup.number().required('Number Of Chips required').max(1000000, 'Max limit should be 1000000'),
        }),
        onSubmit: async values => {
          try {
            const resp = await post(apiRoute.chipsManagement.tranferAmount, { ...values})
            setSuccessMsg(resp?.message);
            setSuccessDialog(true);
        } catch (error) {
            setErrorMsg(error);
            setErrorDialog(true);
        }
        },
      });
      
      const formReset = (event) => {
        event.preventDefault();
        formik.resetForm();
      }
     
      return (
        <Col xl="12">
        <Card>
          <CardBody>
            <form  onSubmit={formik.handleSubmit}
            >
              <Row>
              <Col md="4">
              <div className="mb-3 position-relative">
                    <Label htmlFor="Type">User Type:</Label>
                    <select className="form-select form-control"
                            value={formik.values.userType}
                            name='userType'
                             id="type"
                            onChange={formik.handleChange}>
                           <option defaultValue hidden>Select a value</option>
                            <option value={'Player'}>Player</option>
                          <option value={'Affiliate'}>Affiliate</option>
                          <option value={'Sub Affiliate'}>Sub Affiliate</option>
                        </select>
                        {formik.errors.userType ? (
                  <small className="text-danger">{formik.errors.userType}</small>
                ) : null}
              </div>
            </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="userName">Username:</Label>
                    <Input
                      type="text" name='transferTo'
                      className="form-control"
                      id="userName"
                      placeholder="Enter Username"
                      value={formik.values.transferTo}
                      onChange={formik.handleChange}
                      onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                    />
                     {formik.errors.transferTo ? (
                  <small className="text-danger">{formik.errors.transferTo}</small>
                ) : null}                
                  </div>
                </Col>
                
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="amount">Number Of Chips:</Label>
                    <Input
                      type="number" name='amount'
                      className="form-control"
                      id="amount"
                      placeholder="Total Chips"
                      value={formik.values.amount}
                      onChange={formik.handleChange}
                    />
                    {formik.errors.amount ? (
                  <small className="text-danger">{formik.errors.amount}</small>
                ) : null} 
                  </div>
                </Col>                                
                <Col md="6">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="transactionTypeId">Transaction Type:</Label>
                    <select className="form-select form-control"
                            value={formik.values.transactionType}
                            name='transactionType'
                             id="transactionTypeId"
                            onChange={formik.handleChange}>
                           <option defaultValue hidden>Select a value</option>
                            <option value={'RC'}>RC</option>
                          {formik.values.userType === 'Player' && <option value={'RCB'}>RCB</option>}
                        </select>
                        {formik.errors.transactionType ? (
                  <small className="text-danger">{formik.errors.transactionType}</small>
                ) : null}
                  </div>
                </Col>
              
              <Col md="6">
              <div className="mb-3 position-relative">
                <Label htmlFor="tagDescription">Comment:</Label>
                <Input type='textarea' className="form-control"
                        value={formik.values.tagDescription}
                        name='tagDescription'
                        id='tagDescription'
                        placeholder='Add your comment'
                        rows="1"
                        onChange={formik.handleChange} />
                    {formik.errors.tagDescription ? (
              <small className="text-danger">{formik.errors.tagDescription}</small>
            ) : null}
              </div>
            </Col>
              </Row>
                  
              <div className='d-flex flex-row gap-5 justify-content-center text-center mt-3'>
              <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>
              <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
              </div>
            </form>
          </CardBody>
        </Card>
        {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false); history.push('/transfer-history') }} />}
            {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}           
      </Col>
      )
}

export default connect(null, { setBreadcrumbItems })(TransferAmount);