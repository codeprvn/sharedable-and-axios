import { useState, useEffect } from 'react'
import { useFormik } from 'formik';
import {  Row,  Col,  Card,  CardBody,  Button,  Label,  Input,} from "reactstrap";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { useParams, useHistory } from 'react-router-dom/cjs/react-router-dom';
import { get } from 'helpers/api_helper';
import ErrorPopup from 'common/Popup/ErrorPopup';
import apiRoute from '../../common/ApiURL.json';

const ViewPlayer = (props) => {
    const history = useHistory();
    const [formData, setFormData]  = useState({
      firstName:'',
      lastName: '',
      userName: '',
      dob:'',
      parentUserName:'',
      mobile: '',
      emailId: '',
      rakeBack:'',
      isOrganic:'',
      status:'',
      reasonForBan:'',
      isTopUpAllowed:'',
      topupLimit:'',
      isKYCVerified:true,
      byPassIp:false,   
      });

      const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Player Management", link: "#" },
        { title: "View Player", link: "#" },
      ]
 
        
 // Dailog variable
 const {id} = useParams();
 const [errorDialog, setErrorDialog] = useState(false);
 const [errorMsg, setErrorMsg] = useState('');

    const formik = useFormik({      
        enableReinitialize: true,
        initialValues: formData,
        onSubmit: values => {
               console.log('i m working', values);
        },
      });
      
      async function apiData() {
        try {          
            const resp = await get(apiRoute.playerManagement.listPlayer, { params: { id } })
            setFormData({ ...resp.data });
        } catch (error) {
          setErrorMsg(error);;
            setErrorDialog(true);
        }
      }

    const formReset = (event) => {
      event.preventDefault();
      formik.resetForm();
      history.goBack();
    }
   
    useEffect(() => {
      props.setBreadcrumbItems('Edit Player', breadcrumbItems);
      apiData();
    }, [])

      return (
        <Col xl="12">
        <Card>
          <CardBody>
            <form  onSubmit={formik.handleSubmit}
            >
              <Row>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="firstName">First Name:</Label>
                    <Input
                      type="text" name='firstName'
                      className="form-control"
                      id="firstName"
                      placeholder="Enter First Name"
                      value={formik.values.firstName}
                      onChange={formik.handleChange} readOnly
                    />
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="lastName">Last Name:</Label>
                    <Input
                      type="text" name='lastName'
                      className="form-control"
                      id="lastName"
                      placeholder="Enter First Name"
                      value={formik.values.lastName}
                      onChange={formik.handleChange} readOnly
                    />
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="userName">Username:</Label>
                    <Input
                      type="text" name='userName'
                      className="form-control"
                      id="userName"
                      placeholder="Enter Username"
                      value={formik.values.userName}
                      onChange={formik.handleChange} readOnly
                    />                
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="dob">DOB:</Label>
                    <Input
                      type="date" name='dob'
                      className="form-control"
                      id="dob"
                      value={formik.values.dob}
                    max={ new Date().toISOString().slice(0, 10)}
                      onChange={formik.handleChange} readOnly
                    />
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="affiliateId">Affiliate ID:</Label>
                    <Input
                      type="text" name='parentUserName'
                      className="form-control"
                      id="affiliateId"
                      placeholder="Enter Username"
                      value={formik.values.parentUserName}
                      onChange={formik.handleChange} readOnly
                    />                
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="email">Email:</Label>
                    <Input
                      type="email" name='emailId'
                      className="form-control"
                      id="email"
                      placeholder="Enter Email"
                      value={formik.values.emailId}
                      onChange={formik.handleChange} readOnly
                    />
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="mobileNo">Telephone:</Label>                    
                      <Input
                        type="text" name='mobile'
                        className="form-control"
                        id="mobileNo"
                        placeholder="Enter Mobile"
                        value={formik.values.mobile}
                      onChange={formik.handleChange} readOnly
                      />
                  </div>
                </Col>
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="rakeBack">Rakeback:</Label>
                    <Input
                      type="number" name='rakeBack'
                      className="form-control"
                      id="rakeBack"
                      placeholder="0"
                      value={formik.values.rakeBack}
                      onChange={formik.handleChange} readOnly
                    /> 
                  </div>
                </Col>                                
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="playerTypeId">Player Type:</Label>
                    <select className="form-control"
                            value={formik.values.isOrganic}
                            name='isOrganic'
                             id="playerTypeId"
                            onChange={formik.handleChange} disabled>
                           <option defaultValue hidden>Select a value</option>
                            <option value={true}>Organic</option>
                          <option value={false}>InOrganic</option>
                        </select>
                  </div>
                </Col>
              </Row>
              <Row> 
                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="statusId">Player Status:</Label>
                    <select className="form-control"
                            value={formik.values.status}
                            name='status'
                             id="statusId"
                            onChange={formik.handleChange} disabled>
                           <option defaultValue hidden>Select a value</option>
                            <option value={'Active'}>Active</option>
                          <option value={'Blocked'}>Blocked</option>
                        </select>
                  </div>
                </Col>
                {formik.values.status === 'true' && <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="reasonForBanId">Reason:</Label>
                    <Input
                      type="text" name='reasonForBan'
                      className="form-control"
                      id="reasonForBanId"
                      placeholder="Cheater"
                      value={formik.values.reasonForBan}
                      onChange={formik.handleChange} readOnly />
                  </div>
                </Col>}

                <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="isTopAllowId">Allow Topup:</Label>
                    <select className="form-control"
                            value={formik.values.isTopUpAllowed}
                            name='isTopUpAllowed'
                             id="isTopAllowId"
                            onChange={formik.handleChange} disabled>
                           <option defaultValue hidden>Select a value</option>
                            <option value={true}>Yes</option>
                          <option value={false}>No</option>
                        </select>
                  </div>
                </Col>
               { formik.values.isTopAllow ==='true' && <Col md="4">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="topupLimit">Topup Limit:</Label>
                    <Input type='number' className="form-control"
                            value={formik.values.topupLimit}
                            name='topupLimit'
                            id='topupLimit'
                            placeholder='5000'
                            onChange={formik.handleChange} readOnly />
                  </div>
                </Col>}
                <Col md="6">
                <div className='form-check'>
                <input className="form-check-input" type="checkbox" checked={formik.values.byPassIp} id="byPassIp"
                        onChange={(e) => formik.setFieldValue('byPassIp', e.target.checked)} disabled />
                      <label className="form-check-label" htmlFor="byPassIp">Validate IP</label>
                      </div>
                </Col>
                <Col md="6">
                <div className='form-check'>
                <input className="form-check-input" type="checkbox" checked={formik.values.isKYCVerified} id="isKYCVerified"
                        onChange={(e) => formik.setFieldValue('isKYCVerified', e.target.checked)} disabled />
                      <label className="form-check-label" htmlFor="isKYCVerified">KYC Verified</label>
                </div>
                </Col>
              </Row>
                  
              <div className='d-flex flex-row gap-5 justify-content-center text-center mt-5'>
              <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Back</Button>
              </div>
            </form>
          </CardBody>
        </Card>
      
        {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}            
      </Col>
      )
}

export default connect(null, { setBreadcrumbItems })(ViewPlayer)