import PropTypes from 'prop-types'
import React, { Component, useContext } from "react"
import { ModuleListContext } from 'common/context/moduleListContext';
import {  get } from 'helpers/api_helper';
import apiRoute from '../../common/ApiURL.json';
import ErrorPopup from 'common/Popup/ErrorPopup';
import { connect } from "react-redux"
import { Container } from "reactstrap";
import { withRouter } from "react-router-dom";
import { errorCommon } from 'common/SharedFunction';
import {
  changeLayout,
  changeSidebarTheme,
  changeSidebarType,
  changeTopbarTheme,
  changeLayoutWidth,
} from "../../store/actions"

// Layout Related Components
import Header from "./Header"
import Sidebar from "./Sidebar"
import Footer from "./Footer"
import Rightbar from "../CommonForBoth/Rightbar"
//Import Breadcrumb
import Breadcrumb from "../../components/Common/Breadcrumb"

class Layout extends Component {
  static contextType = ModuleListContext;
  constructor(props) {
    super(props)
    this.state = {
      isMobile: /iPhone|iPad|iPod|Android/i.test(navigator.userAgent),
      errorDialog: false,
      errorMsg: "",
    }
    this.toggleMenuCallback = this.toggleMenuCallback.bind(this)

  
  }

  capitalizeFirstLetter = string => {
    return string.charAt(1).toUpperCase() + string.slice(2)
  }

  

  componentDidMount() {
    const { moduleList, setModuleList } = this.context;
    if (this.props.isPreloader === true) {
      document.getElementById("preloader").style.display = "block"
      document.getElementById("status").style.display = "block"

      setTimeout(function () {
        document.getElementById("preloader").style.display = "none"
        document.getElementById("status").style.display = "none"
      }, 2500)
    } else {
      document.getElementById("preloader").style.display = "none"
      document.getElementById("status").style.display = "none"
    }

    // Scroll Top to 0
    window.scrollTo(0, 0)

    if (this.props.leftSideBarTheme) {
      this.props.changeSidebarTheme(this.props.leftSideBarTheme)
    }

    if (this.props.layoutWidth) {
      this.props.changeLayoutWidth(this.props.layoutWidth)
    }

    if (this.props.leftSideBarType) {
      this.props.changeSidebarType(this.props.leftSideBarType)
    }
    if (this.props.topbarTheme) {
      this.props.changeTopbarTheme(this.props.topbarTheme)
    }
    if (!moduleList.length) {
      
    ( async function fetchData() {
        try {
          const resp = await get(apiRoute.navModuleList);
          setModuleList([...resp]);
        } catch (error) {
          this.setState({
            errorDialog: true,
            errorMsg: errorCommon(error)
          });
        }
      }).bind(this)();
    }
   
  }
  toggleMenuCallback = () => {
    if (this.props.leftSideBarType === "default") {
      this.props.changeSidebarType("condensed", this.state.isMobile)
    } else if (this.props.leftSideBarType === "condensed") {
      this.props.changeSidebarType("default", this.state.isMobile)
    }
  }

  render() {
    return (
      <React.Fragment>
        <div id="preloader">
          <div id="status">
            <div className="spinner-chase">
              <div className="chase-dot"></div>
              <div className="chase-dot"></div>
              <div className="chase-dot"></div>
              <div className="chase-dot"></div>
              <div className="chase-dot"></div>
              <div className="chase-dot"></div>
            </div>
          </div>
        </div>

        <div id="layout-wrapper">
          <Header toggleMenuCallback={this.toggleMenuCallback} />
          <Sidebar
            theme={this.props.leftSideBarTheme}
            type={this.props.leftSideBarType}
            isMobile={this.state.isMobile}
          />
          <div className="main-content">
            <div className="page-content">
              <Container fluid>
                <Breadcrumb />
                {this.props.children}
                {/* render Footer */}
                <Footer />
              </Container>
            </div>
          </div>
          <Footer />
        </div>
        {this.props.showRightSidebar ? <Rightbar /> : null}
        {this.state.errorDialog && <ErrorPopup errorMsg={this.state.errorMsg} onConfirm={() => { this.setState({
            errorDialog: false,
          }); }} />}
      </React.Fragment>
    )
  }
}

Layout.propTypes = {
  changeLayoutWidth: PropTypes.func,
  changeSidebarTheme: PropTypes.func,
  changeSidebarType: PropTypes.func,
  changeTopbarTheme: PropTypes.func,
  children: PropTypes.object,
  isPreloader: PropTypes.any,
  layoutWidth: PropTypes.any,
  leftSideBarTheme: PropTypes.any,
  leftSideBarType: PropTypes.any,
  location: PropTypes.object,
  showRightSidebar: PropTypes.any,
  topbarTheme: PropTypes.any
}

const mapStatetoProps = state => {
  return {
    ...state.Layout,
  }
}
export default connect(mapStatetoProps, {
  changeLayout,
  changeSidebarTheme,
  changeSidebarType,
  changeTopbarTheme,
  changeLayoutWidth,
})(withRouter(Layout))
