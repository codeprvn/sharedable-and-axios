import React , {useEffect, useState} from "react"
import { connect } from "react-redux";
import { Row,  Col,} from "reactstrap";
import { get } from 'helpers/api_helper';
import apiRoute from '../../common/ApiURL.json';

// Pages Components
import Miniwidget from "./Miniwidget"
import MonthlyEarnings from "./montly-earnings";
import MonthlyEarnings2 from "./montly-earnings2";
import Inbox from "./inbox";
import RecentActivity from "./recent-activity";
import WidgetUser from "./widget-user";
import YearlySales from "./yearly-sales";
import LatestTransactions from "./latest-transactions";
import LatestOrders from "./latest-orders";

//Import Action to copy breadcrumb items from local state to redux state
import { setBreadcrumbItems } from "../../store/actions";

const Dashboard = (props) => {
  const [activity, setActivity] = useState([
    { title: "Total Games", name:'totalGames', iconClass: "mdi mdi-gamepad-variant", total: "0"},
    { title: "Total Users", name:'totalUsers', iconClass: "mdi mdi-comment-account", total: "0",},
    { title: "Total Affiliates", name:'totalAffiliates', iconClass: "fas fa-user-friends", total: "0"},    
    { title: "Total SubAffiliates", name:'totalSubAffiliates', iconClass: "fas fa-user-friends", total: "0" },
    { title: "Total Players", name:'totalPlayers', iconClass: "mdi mdi-account-edit", total: "0"},
  ])
  const [chipsData, setChipsData] = useState([])

  async function getActivityData() {
    try{      
        const resp = await get(apiRoute.activity);
        let newActivity = activity.map((item) => {
          const matchingItem = resp.activity.hasOwnProperty(item.name);
          return matchingItem ? { ...item, total: resp.activity[item.name] } : item;
        });
        setActivity(newActivity);
        setChipsData([...resp.transfersMonthlyData])
    }catch(err){
     
    }
}

useEffect(()=>{
    getActivityData()
}, [])


  const breadcrumbItems = [
    { title: "Arcade", link: "#" },
    { title: "Dashboard", link: "#" }
  ]

  useEffect(() => {
    props.setBreadcrumbItems('Dashboard' , breadcrumbItems)
  },)

 

  return (
    <React.Fragment>

      {/*mimi widgets */}
      <Miniwidget reports={activity} />

      <Row>
        {/* <Col xl="6">
          <MonthlyEarnings />
        </Col> */}

        {/* <Col xl="6">
          <EmailSent />
        </Col> */}

        <Col xl="12">
          <MonthlyEarnings2 monthRevenue={chipsData} />
        </Col>

      </Row>
      <Row>

        
      </Row>

     

    </React.Fragment>
  )
}

export default connect(null, { setBreadcrumbItems })(Dashboard);