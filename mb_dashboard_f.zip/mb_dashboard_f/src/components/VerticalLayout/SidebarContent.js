import PropTypes from "prop-types"
import React, { useEffect, useRef, useState, useContext } from "react"
import { ModuleListContext } from "common/context/moduleListContext";

// //Import Scrollbar
import SimpleBar from "simplebar-react"

// MetisMenu
import MetisMenu from "metismenujs"
import { withRouter } from "react-router-dom"
import { Link } from "react-router-dom"

//i18n
import { withTranslation } from "react-i18next"

const SidebarContent = props => {
  const {moduleList}= useContext(ModuleListContext);
  

  const ref = useRef()
  // Use ComponentDidMount and ComponentDidUpdate method symultaniously
  useEffect(() => {
    const pathName = props.location.pathname;

    const initMenu = () => {
      const menu = new MetisMenu("#side-menu");
      let matchingMenuItem = null;
      const ul = document.getElementById("side-menu");
      const items = ul.getElementsByTagName("a");
      for (let i = 0; i < items.length; ++i) {
        if (pathName === items[i].pathname) {
          matchingMenuItem = items[i];
          break;
        }
      }
      if (matchingMenuItem) {
        activateParentDropdown(matchingMenuItem);
      }
      menu.on("shown.metisMenu", () => {
        ref.current.recalculate();
      });
    };

    initMenu();
  }, [props.location.pathname, moduleList]);

  useEffect(() => {
    ref.current.recalculate()
  })




  function scrollElement(item) {
    if (item) {
      const currentPosition = item.offsetTop
      if (currentPosition > window.innerHeight) {
        ref.current.getScrollElement().scrollTop = currentPosition - 300
      }
    }
  }

  function activateParentDropdown(item) {
    item.classList.add("active")
    const parent = item.parentElement
    const parent2El = parent.childNodes[1]
    if (parent2El && parent2El.id !== "side-menu") {
      parent2El.classList.add("mm-show")
    }

    if (parent) {
      parent.classList.add("mm-active")
      const parent2 = parent.parentElement

      if (parent2) {
        parent2.classList.add("mm-show") // ul tag

        const parent3 = parent2.parentElement // li tag

        if (parent3) {
          parent3.classList.add("mm-active") // li
          parent3.childNodes[0].classList.add("mm-active") //a
          const parent4 = parent3.parentElement // ul
          if (parent4) {
            parent4.classList.add("mm-show") // ul
            const parent5 = parent4.parentElement
            if (parent5) {
              parent5.classList.add("mm-show") // li
              parent5.childNodes[0].classList.add("mm-active") // a tag
            }
          }
        }
      }
      scrollElement(item);
      return false
    }
    scrollElement(item);
    return false
  }

  return (
    <React.Fragment>
      <SimpleBar style={{ maxHeight: "100%" }} ref={ref}>
        <div id="sidebar-menu">
          
        <ul className="metismenu list-unstyled" id="side-menu">
            {moduleList.map((module) => (
              <li key={module.id}>
                <Link to={module.route} className={module.subModules.length > 0 ?"has-arrow waves-effect" : "waves-effect"}>
                  <i className={module.iconClass}></i>
                  <span>{props.t(module.name)}</span>
                </Link>

                {module.subModules && module.subModules.length > 0 && (
                  <ul className="sub-menu" aria-expanded="false">
                    {module.subModules.map((subModule, index) => (<li key={index}>
                        <Link to={subModule.route}>
                          {props.t(subModule.name)}
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>


          {/* <ul className="metismenu list-unstyled" id="side-menu">
            <li>
              <Link to="/dashboard" className="waves-effect">
                <i className="mdi mdi-view-dashboard"></i>
                <span>{props.t("Home / Acitivty")}</span>
              </Link>
            </li>

            <li>
              <Link to="/#" className="has-arrow waves-effect">
                <i className="mdi mdi-gamepad-variant"></i>
                <span>{props.t("Game Management")}</span>
              </Link>
              <ul className="sub-menu" aria-expanded="false">
                <li>
                  <Link to="/game-list">{props.t("Game List")}</Link>
                </li>
                <li>
                  <Link to="/add-new-game">{props.t("Add New Game")}</Link>
                </li>
              </ul>
            </li>

            <li>
              <Link to="/#" className="has-arrow waves-effect">
                <i className="mdi mdi-comment-account"></i>
                <span>{props.t("User Management")}</span>
              </Link>

              <ul className="sub-menu" aria-expanded="false">
                <li>
                  <Link to="/create-user">
                    {props.t("Create User")}
                  </Link>
                </li>
                <li>
                  <Link to="/list-user">
                    {props.t("List User")}
                  </Link>
                </li>
              </ul>
            </li>

            <li>
              <Link to="/#" className="has-arrow waves-effect">
                <i className="fas fa-user-friends"></i>
                <span>{props.t("Affiliate Management")}</span>
              </Link>

              <ul className="sub-menu" aria-expanded="false">
                <li>
                  <Link to="/create-affiliate">
                    {props.t("Create Affiliate")}
                  </Link>
                </li>
                <li>
                  <Link to="/create-subAffiliate">
                    {props.t("Create Sub-Affiliate")}
                  </Link>
                </li>
                <li>
                  <Link to="/list-affiliates">
                    {props.t("List Affiliates")}
                  </Link>
                </li>
                <li>
                  <Link to="/list-subaffiliates">
                    {props.t("List Sub-Affiliates")}
                  </Link>
                </li>
              </ul>
            </li>

            <li>
              <Link to="/#" className="has-arrow waves-effect">
                <i className="mdi mdi-account-edit"></i>
                <span>{props.t("Player Management")}</span>
              </Link>

              <ul className="sub-menu" aria-expanded="false">
                <li>
                  <Link to="/create-player">
                    {props.t("Create Player")}
                  </Link>
                </li>
                <li>
                  <Link to="/list-player">
                    {props.t("List Player")}
                  </Link>
                </li>
                <li>
                  <Link to="/daily-login-report">
                    {props.t("Daily Login Report")}
                  </Link>
                </li>
              </ul>
            </li>

            <li>
              <Link to="/#" className="has-arrow waves-effect">
                <i className="mdi mdi-notebook"></i>
                <span>{props.t("Chips Management")}</span>
              </Link>
              <ul className="sub-menu" aria-expanded="false">
                <li>
                  <Link to="/tranfer-to-player">{props.t("Transfer To Players")}</Link>
                </li>
                <li>
                  <Link to="/transfer-to-affiliatessubAffiliates">{props.t("Transfer To Affiliate/Sub-affiliates")}</Link>
                </li>
                <li>
                  <Link to="/transfer-history-players">{props.t("Transfer History Players")}</Link>
                </li>
                <li>
                  <Link to="/transfer-history-affiliatessubaffiliates">{props.t("Transfer History Affiliates/Sub-affiliates")}</Link>
                </li>
                <li>
                  <Link to="/view-txn-history">{props.t("View transaction History")} </Link>
                </li>
              </ul>
            </li>

            <li>
              <Link to="/#" className="has-arrow waves-effect">
                <i className="mdi mdi-bitcoin"></i>
                <span>{props.t("Bonus Management")}</span>
              </Link>
              <ul className="sub-menu" aria-expanded="false">
                <li>
                  <Link to="/#">{props.t("Generate Bonus Code")}</Link>
                </li>
                <li>
                  <Link to="/#">{props.t("Bonus Code List")} </Link>
                </li>
                <li>
                  <Link to="/#">{props.t("Bonus History")} </Link>
                </li>
              </ul>
            </li>

          </ul> */}
        </div>
      </SimpleBar>
    </React.Fragment>
  )
}

SidebarContent.propTypes = {
  location: PropTypes.object,
  t: PropTypes.any,
}

export default withRouter(withTranslation()(SidebarContent))
