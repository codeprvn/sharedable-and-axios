import React from "react"
import { useFormik } from "formik"
import * as Yup from "yup"
import { Row, Col, Card, CardBody, Button, Label, Input } from "reactstrap"
import SharedTable from "common/table/SharedTable"
import { useState, useRef, useEffect } from "react"
import { setBreadcrumbItems } from "../../store/actions"
import { useHistory } from "react-router-dom";
import { connect } from "react-redux"
import { get } from "../../helpers/api_helper"
import { removeEmpty, validFiled } from 'common/SharedFunction';
import ErrorPopup from 'common/Popup/ErrorPopup';
import apiRoute from '../../common/ApiURL.json';

const ListAffiliates = props => {
  // breadcurms title
  const breadcrumbItems = [
    { title: "Arcade", link: "/" },
    { title: "Affiliate Management", link: "#" },
    { title: "List Affiliate", link: "#" },
  ]

  // for defalut data list and set breadcrumbs
  useEffect(() => {
    props.setBreadcrumbItems("List Affiliate", breadcrumbItems)
    apiData()
  }, [])

  // form initial form data
  const formData = { userName: "", name: "", emailId: "", status: "" }

  // State veriable
  const [rows, setRows] = useState([])
  const [totalPage, setTotalPage] = useState(0)
  const [page, setPage] = useState(0)
  const [errorDialog, setErrorDialog] = useState(false)
  const [errorMsg, setErrorMsg] = useState("")
  const isfilter = useRef("")
  const forFilter = useRef("")
  const history = useHistory()

  //action button for table
  const actionButton = [
    { name: "Edit" },
    { name: "View" },
    { name: "Sub-Affiliate" },
    { name: "Player List" },
  ]

  // Table colums and formate
  const columns = [
    { id: "position", label: "No" },
    { id: "name", label: "Name" },
    { id: "userName", label: "Username" },
    { id: "emailId", label: "Email" },
    { id: "status", label: "Status" },
    { id: "commissionPercent", label: "Commission %" },
    { id: "profit", label: "Commission Earned" },
    { id: "creditLimit", label: "Credit Limit" },
   
  ]

  // action button handler
  const actionHandler = (name, id) => {
    const paramId = id.id
    switch (name) {
      case "Edit":
        history.push(`/edit-affiliate/${paramId}`)
        break
      case "View":
        history.push(`/view-affiliate/${paramId}`)
        break
      case "Sub-Affiliate":
        history.push(`/list-subaffiliates/${id.userName}`)
        break
      case "Player List":
        history.push(`/list-player/${id.userName}`)
        break
      default:
        return null
    }
  }

  //Table pagination
  const handleChangePage = async (event, newPage) => {
    setPage(newPage)
    let skip = newPage * 20
    if (isfilter.current === "YES") {
      const resp = await get(apiRoute.affiliateManagement.listAffiliate, {
        params: { ...forFilter.current, skip: skip, limit: 20 },
      })
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData);
    } else {
      const resp = await get(apiRoute.affiliateManagement.listAffiliate, {
        params: { skip: skip, limit: 20 },
      })
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData);
    }
  }

  const apiData = async () => {
    try {
      const resp = await get(apiRoute.affiliateManagement.listAffiliate, {
        params: { skip: 0, limit: 20 },
      })
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData)
      isfilter.current = resp?.isFiltered;
    } catch (error) {
      setErrorMsg(error);
      setErrorDialog(true)
    }
  }

  const formik = useFormik({
    initialValues: formData,
    validateOnMount:true,
    validationSchema: Yup.object({
      userName: Yup.string().required("Username required"),
    }),
    onSubmit: async values => {
      const formData = removeEmpty({ ...values })
      try {
        const resp = await get(apiRoute.affiliateManagement.listAffiliate, {
          params: { ...formData, skip: 0, limit: 20 },
        })
        setPage(0);
        setRows([...resp?.data]);
        forFilter.current = { ...formData }
        isfilter.current = resp?.isFiltered;
        setTotalPage(resp?.totalData)
      } catch (error) {
        setErrorMsg(error);
        setErrorDialog(true)
      }
    },
  })

  // reset form
  const formReset = event => {
    event.preventDefault();
    formik.resetForm();
    setPage(0);
    apiData();
  }

  return (
    <Col xl="12">
      <Card>
        <CardBody>
          <form onSubmit={formik.handleSubmit}>
            <Row>
              <Col md="6">
                <div className="mb-3 position-relative">
                  <Label htmlFor="userName">Username:</Label>
                  <Input
                    type="text"
                    name="userName"
                    className="form-control"
                    id="userName"
                    placeholder="Enter Username"
                    value={formik.values.userName}
                    onChange={formik.handleChange}
                    onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                  />
                  {formik.errors.userName ? (
                    <small className="text-danger">
                      {formik.errors.userName}
                    </small>
                  ) : null}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-3 position-relative">
                  <Label htmlFor="name">First Name:</Label>
                  <Input
                    type="text"
                    name="name"
                    className="form-control"
                    id="name"
                    placeholder="First Name"
                    value={formik.values.name}
                    onChange={formik.handleChange}
                  />
                </div>
              </Col>
              <Col md="6">
                <div className="mb-3 position-relative">
                  <Label htmlFor="email">Email:</Label>
                  <Input
                    type="email"
                    name="emailId"
                    className="form-control"
                    id="email"
                    placeholder="Enter Email"
                    value={formik.values.emailId}
                    onChange={formik.handleChange}
                  />
                </div>
              </Col>

              <Col md="6">
                <div className="mb-3 position-relative">
                  <Label htmlFor="statusId">Status:</Label>
                  <select
                    className="form-select form-control"
                    value={formik.values.status}
                    name="status"
                    id="statusId"
                    onChange={formik.handleChange}
                  >
                    <option defaultValue hidden>
                      Select Affiliate Status
                    </option>
                    <option>Active</option>
                    <option>Blocked</option>
                  </select>
                </div>
              </Col>
            </Row>
            <div className="d-flex flex-row gap-5 justify-content-center text-center mb-3">
              <Button
                type="submit"
                outline
                color="primary"
                className="waves-effect waves-light"
                disabled={validFiled(formik.values)}
              >
                Submit
              </Button>
              <Button
                type="button"
                outline
                color="danger"
                onClick={formReset}
                className="waves-effect waves-light"
              >
                Reset
              </Button>
              {/* <Button
                type="button"
                outline
                color="success"
                className="waves-effect waves-light"
              >
                CSV
              </Button> */}
            </div>
          </form>

          <SharedTable
            columns={columns}
            rows={rows}
            page={page}
            totalPage={totalPage}
            handleChangePage={handleChangePage}
            actionButton={actionButton}
            actionHandler={actionHandler}
          />
        </CardBody>
      </Card>

      {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
    </Col>
  )
}

export default connect(null, { setBreadcrumbItems })(ListAffiliates)
