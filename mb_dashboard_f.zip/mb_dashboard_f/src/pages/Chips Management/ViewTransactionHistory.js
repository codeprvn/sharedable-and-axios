import React, { useState, useRef, useEffect } from 'react';
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import SharedTable from 'common/table/SharedTable';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import ErrorPopup from 'common/Popup/ErrorPopup';
import { dateFormate, validFiled } from 'common/SharedFunction';
import apiRoute from '../../common/ApiURL.json';
import { useListTableHook } from 'common/ModuleList and Hooks/ListTableHook';

const ViewTransactionHistory = (props) => {
  const breadcrumbItems = [
    { title: "Arcade", link: "/" },
    { title: "Chips Management", link: "#" },
    { title: "View transaction History", link: "#" },
  ]


  const columns = [
    { id: 'position', label: 'No' },
    { id: 'name', label: 'Name' },
    { id: 'userName', label: 'Username' },
    { id: 'createdAt', label: 'Date', format: (value) => dateFormate(value) },
    { id: 'referenceNumber', label: 'Reference No' },
    { id: 'amount', label: 'Amount' },
    { id: 'gstAmount', label: 'GST' },
    { id: 'transactionMode', label: 'Transfer Mode' },
    { id: 'paymentId', label: 'Payment ID' },
    { id: 'bonusCode', label: 'Bonus Code' },
    { id: 'approvedBy', label: 'Approved By' },
    { id: 'transactionType', label: 'Transaction Type' },
  ];

  const formData = { userName: '', bonusCode: '', txnType: '', transactionMode: '', sortByValue: '', referenceNo: '', paymentId: '' }

  const { rows, totalPage, page, errorDialog, setErrorDialog, setPage, errorMsg, handlePagination, apiData, onSubmit } = useListTableHook(
    apiRoute.chipsManagement.transactionHistory, formData);

  //Table pagination 
  const handleChangePage = (event, newPage) => {
    let skip = newPage * 20;
    handlePagination(newPage,skip, 20)
  };



  const formik = useFormik({
    initialValues: formData,
    validateOnMount:true,
    validationSchema: Yup.object({
    }),
    onSubmit: onSubmit

  });

  // reset form
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    setPage(0);
    apiData();
  }

  useEffect(() => {
    props.setBreadcrumbItems('View Transaction History', breadcrumbItems)
    apiData();
  }, [])

  return (
    <Col xl="12">
      <Card>
        <CardBody>
          <form onSubmit={formik.handleSubmit}>
            <Row>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="userName">Username:</Label>
                  <Input
                    type="text" name='userName'
                    className="form-control"
                    id="userName"
                    placeholder="Enter Username"
                    value={formik.values.userName}
                    onChange={formik.handleChange}
                    onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                  />
                  {formik.errors.userName ? (
                    <small className="text-danger">{formik.errors.userName}</small>
                  ) : null}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="bonusCode">BonusCode:</Label>
                  <Input
                    type="text" name='bonusCode'
                    className="form-control"
                    id="bonusCode"
                    placeholder="Enter bonusCode"
                    value={formik.values.bonusCode}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.bonusCode ? (
                    <small className="text-danger">{formik.errors.bonusCode}</small>
                  ) : null}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="txnTypeId">Transaction Type:</Label>
                  <select className="form-select form-control"
                    value={formik.values.txnType}
                    name='txnType'
                    id="txnTypeId"
                    onChange={formik.handleChange}>
                    <option defaultValue hidden>Select a value</option>
                    <option>Credit</option>
                    <option>Debit</option>
                  </select>
                  {formik.errors.txnType ? (
                    <small className="text-danger">{formik.errors.txnType}</small>
                  ) : null}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="transactionModeId">Transaction Mode:</Label>
                  <select className="form-select form-control"
                    value={formik.values.transactionMode}
                    name='transactionMode'
                    id="transactionModeId"
                    onChange={formik.handleChange}>
                    <option defaultValue hidden>Select a value</option>
                    <option>Fund Transfer</option>
                    <option>Online Transfer</option>
                    <option>Scratch Card</option>
                  </select>
                  {formik.errors.transactionMode ? (
                    <small className="text-danger">{formik.errors.transactionMode}</small>
                  ) : null}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="sortById">Sort:</Label>
                  <select className="form-select form-control"
                    value={formik.values.sortByValue}
                    name='sortByValue'
                    id="sortById"
                    onChange={formik.handleChange}>
                    <option defaultValue hidden>Select a value</option>
                    <option value={'sortByDate'}>Sort By Date</option>
                    <option value={'sortByAmount'}>Sort By Amount</option>
                  </select>
                  {formik.errors.sortByValue ? (
                    <small className="text-danger">{formik.errors.sortByValue}</small>
                  ) : null}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="referenceNo">Reference No:</Label>
                  <Input
                    type="text" name='referenceNo'
                    className="form-control"
                    id="referenceNo"
                    placeholder="Enter Ref no"
                    value={formik.values.referenceNo}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.referenceNo ? (
                    <small className="text-danger">{formik.errors.referenceNo}</small>
                  ) : null}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="paymentId">Payment ID:</Label>
                  <Input
                    type="text" name='paymentId'
                    className="form-control"
                    id="paymentId"
                    placeholder="Enter Payment Id"
                    value={formik.values.paymentId}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.paymentId ? (
                    <small className="text-danger">{formik.errors.paymentId}</small>
                  ) : null}
                </div>
              </Col>

            </Row>
            <div className='d-flex flex-row gap-5 justify-content-center text-center my-3'>
              <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={validFiled(formik.values)}>Submit</Button>
              <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
              {/* <Button type="button" outline color="success" className="waves-effect waves-light">CSV</Button> */}
            </div>
          </form>

          <SharedTable columns={columns} rows={rows} page={page} totalPage={totalPage} handleChangePage={handleChangePage} />
        </CardBody>
      </Card>
      {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
    </Col>
  )
}

export default connect(null, { setBreadcrumbItems })(ViewTransactionHistory)