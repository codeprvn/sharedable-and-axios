import { createContext, useContext, useState } from "react"

export const ModuleListContext = createContext()

export const ModuleListContextProvider = ({ children }) => {
  const [moduleList, setModuleList] = useState([])
  return (
    <ModuleListContext.Provider value={{ moduleList, setModuleList }}>
      {children}
    </ModuleListContext.Provider>
  )
}