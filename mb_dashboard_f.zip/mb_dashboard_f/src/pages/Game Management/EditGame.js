import { useState, useEffect } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import {  Row,  Col,  Card,  CardBody,  Button,  Label,  Input,} from "reactstrap";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import apiRoute from '../../common/ApiURL.json';
import { get, put } from "../../helpers/api_helper"
import { useHistory, useParams } from 'react-router-dom/cjs/react-router-dom.min';

const EditGame = (props) => {
  const {id} = useParams()
  const {location, goBack, push} = useHistory()
  const isView = location.pathname.includes('view')
    const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Game Management", link: "#" },
        { title: "Edit Game", link: "#" },
      ] 

      const [formData, setFormData] = useState({
        name:'',
        type:'',
        status:'',
        imageUrl:'',
        gameLink:'',
        token:'',
        key:'',
        isTrending:false
    });

 // Dailog variable
const [successDialog, setSuccessDialog ] = useState(false);
const [successMsg, setSuccessMsg] = useState('');
const [errorDialog, setErrorDialog ] = useState(false);
const [errorMsg, setErrorMsg] = useState('')

 async function apiData(){
try{
  const resp = await get(`${apiRoute.gameManagement.listGame}`,{ params: { id } });
  setFormData({ ...resp.data });
  
}catch(error){
  setErrorMsg(error);
  setErrorDialog(true);
}

}


  const formik = useFormik({
    initialValues: formData,
    enableReinitialize: true,
    validationSchema: Yup.object({
      name: Yup.string().required('Game Name is required'),
      type: Yup.string().required('Game Type is required'),
      status: Yup.string().required('Status is required'),
      imageUrl:Yup.string().required('Image Url is required'),
    gameLink:Yup.string().required('Game Link is required'),
    }),
    onSubmit: async values => {
      try {
        const newObject = { 
           name: values.name,
            type: values.type,
            imageUrl: values.imageUrl,
            gameLink: values.gameLink,
            reportingTo: values.reportingTo,
            status: values.status,
            token: values.token,
            key: values.key,
            isTrending: values.isTrending};
            const resp = await put(`${apiRoute.gameManagement.updateGame}/${id}`, {...newObject })
            setSuccessMsg(resp?.message)
            setSuccessDialog(true)
        } catch (error) {
            setErrorMsg(error);
            setErrorDialog(true);
        }
    
    },
  });
  
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    goBack();
}
 
  useEffect(() => {
    props.setBreadcrumbItems('Edit Game', breadcrumbItems);
    apiData();
  },[])
  return (
    <Col xl="12">
    <Card>
      <CardBody>
        <form  onSubmit={formik.handleSubmit}
        >
          <Row>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="name">Game Name:</Label>
                <Input
                  type="text" name='name'
                  className="form-control"
                  id="name"
                  placeholder="Enter Game Name"
                  value={formik.values.name}
                  onChange={formik.handleChange} readOnly={isView}
                />
                {formik.errors.name ? (
              <small className="text-danger">{formik.errors.name}</small>
            ) : null}
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="gameTypeId">Game Type:</Label>
                <select className="form-select form-control"
                        value={formik.values.type}
                        name='type' id='gameTypeId'  disabled={isView}
                        onChange={formik.handleChange}>
                       <option defaultValue hidden>Select a Value</option>
                      <option value={'Casino Games'}>Casino Games</option>
                      <option value={'House of Cards'}>House of Cards</option>
                      <option value={'Casual Games'}>Casual Games</option>
                    </select>
                    {formik.errors.type ? (
              <small className="text-danger">{formik.errors.type}</small>
            ) : null}
              </div>
            </Col>
            
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="statusId">Status:</Label>
                 <select className="form-select form-control" name='status'
                  id="statusId" disabled={isView}
                  value={formik.values.status}
                  onChange={formik.handleChange}>
                     <option defaultValue hidden>Select a value</option>
                      <option value={'Active'}>Active</option>
                      <option value={'InActive'}>Inactive</option>
                  </select> 
                  {formik.errors.status ? (
              <small className="text-danger">{formik.errors.status}</small>
            ) : null}                
              </div>
            </Col>

             <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="imageUrl">Image Url:</Label>
                <Input
                  type="text" name='imageUrl'
                  className="form-control"
                  id="imageUrl" readOnly={isView}
                  placeholder="Enter Image Url"
                  value={formik.values.imageUrl}
                  onChange={formik.handleChange}
                />
                {formik.errors.imageUrl ? (
              <small className="text-danger">{formik.errors.imageUrl}</small>
            ) : null}
              </div>
            </Col>       

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="gameLink">Game Link:</Label>
                <Input 
                  type="text" name='gameLink'
                  className="form-control"
                  id="gameLink" readOnly={isView}
                  placeholder="Enter Game link"
                  value={formik.values.gameLink}
                  onChange={formik.handleChange}
                />
                {formik.errors.gameLink ? (
              <small className="text-danger">{formik.errors.gameLink}</small>
            ) : null}
              </div>
            </Col>

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="token">Token:</Label>
                <Input
                  type="text" name='token'
                  className="form-control"
                  id="token" readOnly={isView}
                  value={formik.values.token}
                  onChange={formik.handleChange}
                />
                {formik.errors.token ? (
              <small className="text-danger">{formik.errors.token}</small>
            ) : null}
              </div>
            </Col> 

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="token">Key:</Label>
                <Input 
                  type="text" name='key'
                  className="form-control"
                  id="key" readOnly={isView}
                  value={formik.values.key}
                  onChange={formik.handleChange}
                />
                {formik.errors.key ? (
              <small className="text-danger">{formik.errors.key}</small>
            ) : null}
              </div>
            </Col> 

            <Col md="4" className='align-self-center'>
                <div className='form-check'>
                <input className="form-check-input" type="checkbox" checked={formik.values.isTrending} id="isTrending"
                        onChange={formik.handleChange} disabled={isView} /> 
                      <label className="form-check-label" htmlFor="isKYCVerified">Trending</label>
                </div>
                </Col>

            </Row>

          <div className='d-flex flex-row gap-5 justify-content-center text-center mt-3'>
          {!isView && <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>}
          <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Back</Button>
          </div>
        </form>
      </CardBody>
    </Card>
    {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false); push('/game-list') }} />}
            {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}           
  </Col>
  )
}

export default connect(null, { setBreadcrumbItems })(EditGame);