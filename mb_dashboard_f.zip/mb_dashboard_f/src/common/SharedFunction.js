
// this function will remove all the emplty key from object
export const removeEmpty = (obj)=>{
    Object.keys(obj).forEach( key =>{                
        if(obj[key] === '' || obj[key] === null || obj[key] === undefined || obj[key] === ''){
            delete obj[key];
        }
       else if (typeof obj[key] === 'string' ){
        obj[key] = obj[key].trim();
       }
    })
    return obj
}

export const emailMask = (email) =>{
    let toMask = false;
let count = 0;
for(let i=0;i<email.length;i++){
    if(count===3){
        toMask=!toMask
        count=0
    }
    if(toMask){
      let characters = email.split('');
      characters[i] = '*';
      let result = characters.join('');
      email = result
    }
    count++;
}
return email
}

export const dateFormate = (value) =>{
    if(value){
    const d = new Date(value);
    return `${(d.getMonth() + 1)}/${d.getDate()}/${String(d.getFullYear()).slice(-2)}, ${d.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true })}`
}  
}

  export const errorCommon = (error) =>{    
    if( Array.isArray(error?.response?.data?.message)){
        return error?.response?.data?.message[0]
    }
    else if( error?.response?.data?.message){
        return error?.response?.data?.message
    }else{
        return 'Something Went Wrong'
    }
  }

  export const mobileMask = (value) =>{
   return value.slice(-4).padStart(value.length, '*') 
  }

  export const inputDate = (value)=>{
    return new Date(value).toISOString().slice(0, 10)
  }

  export const validFiled =(value)=>{
   return !Object.values(value).some(val => val !== '' && val !== null && val !== undefined);
  }