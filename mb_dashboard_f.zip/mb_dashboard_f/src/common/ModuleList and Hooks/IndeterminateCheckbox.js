
import { FormGroup, Label, Input } from 'reactstrap';

const IndeterminateCheckbox = ({ index, label, checked, onChange, children, childrenHandle, isDisabled=false }) => (
  <div className='my-2'>
    <FormGroup check>
      <Label check>
        <Input type="checkbox" checked={checked} onChange={() => onChange(index)} disabled={isDisabled} />
        {label}
      </Label>
    </FormGroup>
    <div style={{ marginLeft: '20px' }}>
      {children?.map((child, childIndex) => (
        <FormGroup check key={childIndex}>
        <Label check>
          <Input type="checkbox" checked={child.status} onChange={() => childrenHandle(childIndex)} disabled={isDisabled} />
          {child.name}
        </Label>
      </FormGroup>
        // <IndeterminateCheckbox
        //   key={childIndex}
        //   label={child.subname}
        //   checked={child.completed}
        //   onChange={() => childrenHandle(childIndex)}
        // />
      ))}
    </div>
  </div>
);

  export default IndeterminateCheckbox