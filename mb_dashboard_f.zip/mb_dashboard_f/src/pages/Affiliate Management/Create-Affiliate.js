import { useState, useEffect } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import IndeterminateCheckbox from '../../common/ModuleList and Hooks/IndeterminateCheckbox';
import useCheckList from '../../common/ModuleList and Hooks/CheckListHook';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { post, get } from 'helpers/api_helper';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import apiRoute from '../../common/ApiURL.json';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';


const CreateAffiliate = (props) => {
    const history = useHistory()
    const formData = {
        name: '',
        userName: '',
        mobile: '',
        emailId: '',
        panCard: '',
        creditLimit: '',
        commissionPercent: '',
        city: '',
        dob: '',
        status: '',
        address: '',
        password: '',
        branchName:'',
        accountNumber:'',
        IFSCode: '',
        accountName:''
    }

    const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Affiliate Management", link: "#" },
        { title: "Create Affiliate", link: "#" },
    ]

    useEffect(() => {
        props.setBreadcrumbItems('Create Affiliate', breadcrumbItems)
    })



    // Dailog variable
    const [successDialog, setSuccessDialog] = useState(false)
    const [successMsg, setSuccessMsg] = useState('');
    const [errorDialog, setErrorDialog] = useState(false)
    const [errorMsg, setErrorMsg] = useState('');
    const { checkboxData, handleChangeParent, handleChangeChild, setCheckboxData } = useCheckList([]);



    const formik = useFormik({
        initialValues: formData,
        validateOnMount:true,
        validationSchema: Yup.object({
            name: Yup.string().required('Name required'),
            userName: Yup.string().required('Username required').max(20, 'Max 20 digit required').min(3, 'Min 3 digit required'),
            mobile: Yup.string().required('Mobile No required').max(10, 'Max 10 digit required').min(10, 'Min 10 digit required'),
            emailId: Yup.string().email('Enter a valid Email').required('Email required'),
            panCard: Yup.string().optional(),
            creditLimit: Yup.number().required('Credit Limit required'),
            commissionPercent: Yup.number().required('Commission Percent required').min(0).max(100),
            city: Yup.string().optional(),
            dob: Yup.date().required('DOB required'),
            status: Yup.string().required('Status required'),
            address: Yup.string().optional(),
            password: Yup.string().required('Password required').matches(/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&*!])[A-Za-z\d@#$%^&*!]+$/, 'One uppercase, one numeric, and one special character required').min(8, 'Password must contain at least 8 characters'),
            branchName:Yup.string().optional(),
            accountNumber:Yup.string().optional().matches(/^[0-9]+$/, 'Only Number allowed'),
            IFSCode: Yup.string().optional(),
            accountName:Yup.string().optional(),
        }),
        onSubmit: async values => {
            let createdBy = JSON.parse(localStorage.getItem('authUser'));
            try {
                const resp = await post(apiRoute.affiliateManagement.createAffiliate, { ...values, modules: checkboxData, createdBy: createdBy.userName })
                setSuccessMsg(resp?.message)
                setSuccessDialog(true)
            } catch (error) {
                setErrorMsg(error);
                setErrorDialog(true);
            }
        },
    });

    async function getModuleList (){
        try{
            const resp = await get(apiRoute.moduleList, {params: {'key':'affiliate'}})
            setCheckboxData(resp)
        }
        catch(error){
            setErrorMsg(error);
            setErrorDialog(true);
        }
    }

    const formReset = (event) => {
        event.preventDefault();
        formik.resetForm();
    }

    useEffect(() => {
        props.setBreadcrumbItems('Create Affiliate', breadcrumbItems);
        getModuleList();
    }, [])

    return (
        <Col xl="12">
            <Card>
                <CardBody>
                    <form onSubmit={formik.handleSubmit}
                    >
                        <Row>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip01">Name:</Label>
                                    <Input
                                        type="text" name='name'
                                        className="form-control"
                                        id="validationTooltip01"
                                        placeholder="Enter Name"
                                        value={formik.values.name}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.name ? (
                                        <small className="text-danger">{formik.errors.name}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip02">Username:</Label>
                                    <Input
                                        type="text" name='userName'
                                        className="form-control"
                                        id="validationTooltip02"
                                        placeholder="Enter Username"
                                        value={formik.values.userName}
                                        onChange={formik.handleChange}
                                        onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                                    />
                                    {formik.errors.userName ? (
                                        <small className="text-danger">{formik.errors.userName}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="mobile">Telephone:</Label>

                                    <PhoneInput
                     disableDialCodeAndPrefix={true}
                     disableFormatting={true}
                     inputClassName='form-control'
                         defaultCountry="in" name='mobile'
                        id="mobile"
                        placeholder="Enter Mobile"
                        value={formik.values.mobile}
                      onChange={(data, meta) => {
                        formik.setFieldValue('mobile',meta.inputValue);
                      }}
                      />
                                    {formik.errors.mobile ? (
                                        <small className="text-danger">{formik.errors.mobile}</small>
                                    ) : null}
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="email03">Email:</Label>
                                    <Input
                                        type="email" name='emailId'
                                        className="form-control"
                                        id="email03"
                                        placeholder="Enter Email"
                                        value={formik.values.emailId}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.emailId ? (
                                        <small className="text-danger">{formik.errors.emailId}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="panCard">Pan Card:</Label>
                                    <Input
                                        type="text" name='panCard'
                                        className="form-control"
                                        id="panCard"
                                        placeholder="XXX123"
                                        value={formik.values.panCard}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.panCard ? (
                                        <small className="text-danger">{formik.errors.panCard}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip03">Password:</Label>
                                    <Input type="password" name='password'
                                        className="form-control"
                                        id="validationTooltip03"
                                        placeholder="Enter Password"
                                        value={formik.values.password}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.password ? (
                                        <small className="text-danger">{formik.errors.password}</small>) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="branchName">Branch Name:</Label>
                                    <Input type="text" name='branchName'
                                        className="form-control"
                                        id="branchName"
                                        placeholder="Enter Branch Name"
                                        value={formik.values.branchName}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.branchName ? (
                                        <small className="text-danger">{formik.errors.branchName}</small>) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="accountName">Account Name:</Label>
                                    <Input type="text" name='accountName'
                                        className="form-control"
                                        id="accountName"
                                        placeholder="Enter Account Name"
                                        value={formik.values.accountName}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.accountName ? (
                                        <small className="text-danger">{formik.errors.accountName}</small>) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="accountNumber">Account number:</Label>
                                    <Input type="text" name='accountNumber'
                                        className="form-control"
                                        id="accountNumber"
                                        placeholder="Enter Account Number"
                                        value={formik.values.accountNumber}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.accountNumber ? (
                                        <small className="text-danger">{formik.errors.accountNumber}</small>) : null}
                                </div>
                            </Col>

                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="IFSCode">IFSC:</Label>
                                    <Input type="text" name='IFSCode'
                                        className="form-control"
                                        id="IFSCode"
                                        placeholder="Enter IFSC"
                                        value={formik.values.IFSCode}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.IFSCode ? (
                                        <small className="text-danger">{formik.errors.IFSCode}</small>) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="creditLimit">Credit Limit:</Label>
                                    <Input
                                        type="number" name='creditLimit'
                                        className="form-control"
                                        id="creditLimit"
                                        placeholder="1000"
                                        value={formik.values.creditLimit}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.creditLimit ? (
                                        <small className="text-danger">{formik.errors.creditLimit}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="commissionPercent">Commission Percent:</Label>
                                    <Input
                                        type="number" name='commissionPercent'
                                        className="form-control"
                                        id="commissionPercent"
                                        placeholder="100"
                                        value={formik.values.commissionPercent}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.commissionPercent ? (
                                        <small className="text-danger">{formik.errors.commissionPercent}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="city">City:</Label>
                                    <Input
                                        type="text" name='city'
                                        className="form-control"
                                        id="city"
                                        placeholder="New Delhi"
                                        value={formik.values.city}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.city ? (
                                        <small className="text-danger">{formik.errors.city}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="dob">Date Of Birth:</Label>
                                    <Input
                                        type="date" name='dob'
                                        className="form-control"
                                        id="dob"
                                        value={formik.values.dob}
                                        onChange={formik.handleChange}
                                        max={ new Date().toISOString().slice(0, 10)}
                                    />
                                    {formik.errors.dob ? (
                                        <small className="text-danger">{formik.errors.dob}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="statusId">Status:</Label>
                                    <select className=" form-select form-control"
                                        value={formik.values.status}
                                        name='status'
                                        id="statusId"
                                        onChange={formik.handleChange}>
                                        <option defaultValue hidden>Select Player Status</option>
                                        <option>Active</option>
                                        <option>Blocked</option>
                                    </select>
                                    {formik.errors.status ? (
                                        <small className="text-danger">{formik.errors.status}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="address">Address:</Label>
                                    <Input type='textarea' className="form-control"
                                        value={formik.values.address}
                                        name='address'
                                        id='address'
                                        rows="1"
                                        onChange={formik.handleChange} />
                                    {formik.errors.address ? (
                                        <small className="text-danger">{formik.errors.address}</small>
                                    ) : null}
                                </div>
                            </Col>
                        </Row>
                        <div className="container-fluid text-center bg-dark text-white fs-3 p-2 my-10"><span> Modules / Sub-Modules </span></div>

                        {checkboxData?.map((checkbox, index) => (
                            <IndeterminateCheckbox
                                key={index}
                                index={index}
                                label={checkbox.name}
                                checked={checkbox.allTicked}
                                onChange={handleChangeParent}
                                children={checkbox.subModules}
                                childrenHandle={(childIndex) => handleChangeChild(index, childIndex)}
                            />
                        ))}

                        <div className='d-flex flex-row gap-5 justify-content-center text-center mt-5'>
                            <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid} >Submit</Button>
                            <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
                        </div>
                    </form>
                </CardBody>
            </Card>
            {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false); history.push('/list-affiliates') }} />}
            {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
        </Col>
    )
}


export default connect(null, { setBreadcrumbItems })(CreateAffiliate)