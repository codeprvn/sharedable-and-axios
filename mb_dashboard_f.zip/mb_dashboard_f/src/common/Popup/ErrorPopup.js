import React from 'react'
import Dialog from '@mui/material/Dialog';
import { Button} from "reactstrap";
import './success.scss'
import { errorCommon} from 'common/SharedFunction';

const ErrorPopup = ({ errorMsg, confirmBtnText,  onConfirm }) => {
    
    return (
  
    <Dialog open={true} onClose={onConfirm} aria-labelledby="alert-dialog-title" className='oueter' aria-describedby="alert-dialog-description">
      <div className='popUpContainer'>
        <div className="symbol">X</div>
        <h2 className="text">{errorCommon(errorMsg)}</h2>
        <div className='closeBtn'>
          <Button
             type="button" color="danger" className="waves-effect waves-light"
            onClick={() => {
              onConfirm();
            }} >
            {confirmBtnText || 'Close'}
          </Button>
        </div>
      </div>
    </Dialog>
  
    )
}

export default ErrorPopup