import { useState, useEffect, useRef } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import SharedTable from 'common/table/SharedTable';
import { useHistory } from "react-router-dom";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { get } from "../../helpers/api_helper"
import { removeEmpty, dateFormate, validFiled } from 'common/SharedFunction';
import ErrorPopup from 'common/Popup/ErrorPopup';
import apiRoute from '../../common/ApiURL.json';

const ListUser = (props) => {

  // breadcurms title
  const breadcrumbItems = [
    { title: "Arcade", link: "/" },
    { title: "User Management", link: "#" },
    { title: "List User", link: "#" },
  ]


  // form initial form data
  const formData = { userName: '', emailId: '', role: '', status: '', }

  const isMounted = useRef(true);
  // State veriable
  const [rows, setRows] = useState([]);
  const [totalPage, setTotalPage] = useState(0);
  const [page, setPage] = useState(0);
  const [errorDialog, setErrorDialog] = useState(false)
  const [errorMsg, setErrorMsg] = useState('');
  const isfilter = useRef('');
  const forFilter = useRef('');
  const history = useHistory();

  //action button for table
  const actionButton = [{ name: 'Edit' }, { name: 'View' }]

  // Table colums and formate
  const columns = [
    { id: 'position', label: 'No' },
    { id: 'name', label: 'Name' },
    { id: 'userName', label: 'Username' },
    { id: 'emailId', label: 'Email' },
    { id: 'role', label: 'Level' },
    { id: 'createdBy', label: 'Created By' },
    { id: 'createdAt', label: 'Created On', format:(value)=> dateFormate(value)},
    { id: 'status', label: 'Status' },
  ];

  // action button handler
  const actionHandler = (name, id) => {
    const paramId = id.id
    if (name === 'Edit') {
      history.push(`/edit-user/${paramId}`)
    }
    if (name === 'View') history.push(`/view-user/${paramId}`);
  }

  //Table pagination 
  const handleChangePage = async (event, newPage) => {
    setPage(newPage);
    let skip = newPage * 20;
    if (isfilter.current === 'YES') {
      const resp = await get(apiRoute.userManagement.listUser, { params: { ...forFilter.current, skip: skip, limit: 20 } })
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData);
    }
    else {
      const resp = await get(apiRoute.userManagement.listUser, { params: { skip: skip, limit: 20 } })
      setRows([...resp?.data]);
      setTotalPage(resp?.totalData);
    }
  };

  const apiData = async () => {
    try {
      const resp = await get(apiRoute.userManagement.listUser, { params: { skip: 0, limit: 20 } })
      if(isMounted.current){
        setRows([...resp?.data]);
      setTotalPage(resp?.totalData)
      isfilter.current = resp?.isFiltered;}
    } catch (error) {
      if (isMounted.current){
        setErrorMsg(error);
      setErrorDialog(true);}
    }
  }

  // form validation
  const formik = useFormik({
    initialValues: formData,
    validationSchema: Yup.object({
      userName: Yup.string(),
    }),
    onSubmit: async values => {
      const formData = removeEmpty({ ...values })
      try {
        const resp = await get(apiRoute.userManagement.listUser, { params: { ...formData, skip: 0, limit: 20 } })
        setPage(0);
        setRows([...resp?.data]);
        forFilter.current = { ...formData }
        isfilter.current = resp?.isFiltered;
        setTotalPage(resp?.totalData)

      } catch (error) {
        setErrorMsg(error);
        setErrorDialog(true);
      }
    },
  });

  // for defalut data list and set breadcrumbs
  useEffect(() => {
    isMounted.current = true;
    props.setBreadcrumbItems('List User', breadcrumbItems);
    apiData();

    //clean up
    return () => {
      isMounted.current = false;
    };

  }, [])

  // reset form
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    setPage(0);
    apiData();
  }

  return (
    <>
      <Col xl="12">
        <Card>
          <CardBody>
            <form onSubmit={formik.handleSubmit}
            >
              <Row>

                <Col md="6">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="validationTooltip02">Username:</Label>
                    <Input
                      type="text" name='userName'
                      className="form-control"
                      id="validationTooltip02"
                      placeholder="Enter Username"
                      value={formik.values.userName}
                      onChange={formik.handleChange}
                      onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                    />
                    {formik.errors.userName ? (
                      <small className="text-danger">{formik.errors.userName}</small>
                    ) : null}
                  </div>
                </Col>

                <Col md="6">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="validationTooltip03">Email:</Label>
                    <Input
                      type="email" name='emailId'
                      className="form-control"
                      id="validationTooltip03"
                      placeholder="Enter Email"
                      value={formik.values.emailId}
                      onChange={formik.handleChange}
                    />
                  </div>
                </Col>
                <Col md="6">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="validationTooltip04">Role:</Label>
                    <select className="form-select form-control" name='role'
                      id="validationTooltip04"
                      value={formik.values.role}
                      onChange={formik.handleChange}>
                      <option defaultValue hidden>Select a value</option>
                      <option>Director</option>
                      <option>General Manager</option>
                      <option>Senior Delivery Manager</option>
                      <option>Team Lead</option>
                      <option>Senior Executive</option>
                      <option>Executive</option>
                    </select>
                  </div>
                </Col>
                <Col md="6">
                  <div className="mb-3 position-relative">
                    <Label htmlFor="validationTooltip04">Status:</Label>
                    <select className="form-select form-control"
                      value={formik.values.status}
                      name='status'
                      onChange={formik.handleChange}>
                      <option defaultValue hidden>Select user Status</option>
                      <option>Active</option>
                      <option>Blocked</option>
                    </select>
                  </div>
                </Col>
              </Row>


              <div className='d-flex flex-row gap-5 justify-content-center text-center mb-3'>
                <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={validFiled(formik.values)}>Submit</Button>
                <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
                {/* <Button type="button" outline color="success" className="waves-effect waves-light">CSV</Button> */}
              </div>
            </form>

            <SharedTable columns={columns} rows={rows} page={page} totalPage={totalPage} handleChangePage={handleChangePage} actionButton={actionButton}
              actionHandler={actionHandler} />
          </CardBody>
        </Card>
        {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
      </Col>
    </>
  )
}

export default connect(null, { setBreadcrumbItems })(ListUser)