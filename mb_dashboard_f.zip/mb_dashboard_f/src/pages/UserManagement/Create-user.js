import { useState, useEffect } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import IndeterminateCheckbox from '../../common/ModuleList and Hooks/IndeterminateCheckbox';
import useCheckList from '../../common/ModuleList and Hooks/CheckListHook';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { post, get } from 'helpers/api_helper';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import apiRoute from '../../common/ApiURL.json';
import { useHistory } from "react-router-dom";

const CreateUser = (props) => {
    const history = useHistory()
    // breadcurms title
    const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "User Management", link: "#" },
        { title: "Create User", link: "#" },
    ]  
    const formData = {
        name: '',
        userName: '',
        mobile: '',
        emailId: '',
        password: '',
        reportingTo: '',
        status: '',
        role: '',
    }

    // Dailog variable
    const [successDialog, setSuccessDialog] = useState(false);
    const [successMsg, setSuccessMsg] = useState('');
    const [errorDialog, setErrorDialog] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');
    const { checkboxData, handleChangeParent, handleChangeChild, setCheckboxData } = useCheckList([]);

    // form validation
    const formik = useFormik({
        initialValues: formData,
        validateOnMount:true,
        validationSchema: Yup.object({
            name: Yup.string().required('Name required'),
            userName: Yup.string().required('Username required').max(20, 'Max 20 digit required').min(3, 'Min 3 digit required'),
            mobile: Yup.string().required('Mobile No required').max(10, 'Max 10 digit required').min(10, 'Min 10 digit required'),
            emailId: Yup.string().email('Enter a valid Email').required('Email required'),
            password: Yup.string().required('Password required').matches(/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&*!])[A-Za-z\d@#$%^&*!]+$/, 'One uppercase, one numeric, and one special character required').min(8, 'Password must contain at least 8 characters'),
            reportingTo: Yup.string().required('Reporting to required'),
            status: Yup.string().required('Player Status required'),
            role: Yup.string().required('Level required'),
        }),
        onSubmit: async values => {
            let createdBy = JSON.parse(localStorage.getItem('authUser'));
            try {
                const resp = await post(apiRoute.userManagement.createUser, { ...values, modules: checkboxData, createdBy: createdBy.userName })
                setSuccessMsg(resp?.message)
                setSuccessDialog(true)
            } catch (error) {
                setErrorMsg(error);
                setErrorDialog(true);
            }
        },
    });

    const formReset = (event) => {
        event.preventDefault();
        formik.resetForm();
    }

    async function getModuleList (){
        try{
            const resp = await get(apiRoute.moduleList, {params: {'key':'user'}})
            setCheckboxData(resp)
        }
        catch(error){
            setErrorMsg(error);
            setErrorDialog(true);
        }
    }

     // for defalut data list and set breadcrumbs
     useEffect(() => {
        props.setBreadcrumbItems('Create User', breadcrumbItems);
        getModuleList();
    }, []) 

    return (
        <Col xl="12">
            <Card>
                <CardBody>
                    <form onSubmit={formik.handleSubmit}
                    >
                        <Row>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip01">Name:</Label>
                                    <Input
                                        type="text" name='name'
                                        className="form-control"
                                        id="validationTooltip01"
                                        placeholder="Enter Name"
                                        value={formik.values.name}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.name ? (
                                        <small className="text-danger">{formik.errors.name}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip02">Username:</Label>
                                    <Input
                                        type="text" name='userName'
                                        className="form-control"
                                        id="validationTooltip02"
                                        placeholder="Enter Username"
                                        onKeyDown={(e)=> { if (e.key === " ") return e.preventDefault()}}
                                        value={formik.values.userName}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.userName ? (
                                        <small className="text-danger">{formik.errors.userName}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="mobile">Telephone:</Label>

                     <PhoneInput
                     disableDialCodeAndPrefix={true}
                     disableFormatting={true}
                     inputClassName='form-control'
                         defaultCountry="in" name='mobile'
                        id="mobile"
                        placeholder="Enter Mobile"
                        value={formik.values.mobile}
                      onChange={(data, meta) => {
                        formik.setFieldValue('mobile',meta.inputValue);
                      }}
                      />
                                    {formik.errors.mobile ? (
                                        <small className="text-danger">{formik.errors.mobile}</small>
                                    ) : null}
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="vali03">Email:</Label>
                                    <Input
                                        type="email" name='emailId'
                                        className="form-control"
                                        id="vali03"
                                        placeholder="Enter Email"
                                        value={formik.values.emailId}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.emailId ? (
                                        <small className="text-danger">{formik.errors.emailId}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip03">Password:</Label>
                                    <Input
                                        type="password" name='password'
                                        className="form-control"
                                        id="validationTooltip03"
                                        placeholder="Enter Password"
                                        value={formik.values.password}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.password ? (
                                        <small className="text-danger">{formik.errors.password}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Reporting To:</Label>
                                    <Input
                                        type="text" name='reportingTo'
                                        className="form-control"
                                        id="validationTooltip04"
                                        placeholder="Enter Reporting To"
                                        value={formik.values.reportingTo}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.reportingTo ? (
                                        <small className="text-danger">{formik.errors.reportingTo}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Player Status:</Label>
                                    <select className="form-select form-control"
                                        value={formik.values.status}
                                        name='status'
                                        onChange={formik.handleChange}>
                                        <option defaultValue hidden>Select Player Status</option>
                                        <option>Active</option>
                                        <option>Blocked</option>
                                    </select>
                                    {formik.errors.status ? (
                                        <small className="text-danger">{formik.errors.status}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Level:</Label>
                                    <select className="form-select form-control"
                                        value={formik.values.level}
                                        name='role'
                                        onChange={formik.handleChange}>
                                        <option defaultValue hidden>Select a Level</option>
                                        <option>Director</option>
                                        <option>General Manager</option>
                                        <option>Senior Delivery Manager</option>
                                        <option>Team Lead</option>
                                        <option>Senior Executive</option>
                                        <option>Executive</option>
                                    </select>
                                    {formik.errors.role ? (
                                        <small className="text-danger">{formik.errors.role}</small>
                                    ) : null}
                                </div>
                            </Col>
                        </Row>
                        <div className="container-fluid text-center bg-dark text-white fs-3 p-2 my-10"><span> Modules / Sub-Modules </span></div>

                        {checkboxData?.map((checkbox, index) => (
                            <IndeterminateCheckbox
                                key={index}
                                index={index}
                                label={checkbox.name}
                                checked={checkbox.allTicked}
                                onChange={handleChangeParent}
                                children={checkbox.subModules}
                                childrenHandle={(childIndex) => handleChangeChild(index, childIndex)}
                            />
                        ))}

                        <div className='d-flex flex-row gap-5 justify-content-center text-center mt-5'>
                            <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>
                            <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
                        </div>
                    </form>
                </CardBody>
            </Card>
            {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false);
            history.push(`/list-user`) }} />}
            {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
        </Col>
    )
}

export default connect(null, { setBreadcrumbItems })(CreateUser);