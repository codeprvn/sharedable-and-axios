import { useState, useEffect, useRef } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import {  Row,  Col,  Card,  CardBody,  Button,  Label,  Input,} from "reactstrap";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import SharedTable from 'common/table/SharedTable';
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import { useListTableHook } from 'common/ModuleList and Hooks/ListTableHook';
import apiRoute from '../../common/ApiURL.json';
import { dateFormate } from 'common/SharedFunction';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';
import { del } from 'helpers/api_helper';


const GameList = (props) => {
  const history= useHistory();
 
    const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Game Management", link: "#" },
        { title: "Game List", link: "#" },
      ]

      const columns = [
        { id: 'position', label: 'No' },
        { id: 'name', label: 'Game Name' },
        { id: 'createdAt', label: 'Game Integrated', format: (value) => dateFormate(value) },
        { id: 'revenue', label: 'Total Revenue' },
        { id: 'status', label: 'Status' },
      ]
   

  const formdata = { name: '', status:'' };
  const [successDialog, setSuccessDialog ] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');


  const { rows, totalPage, page, errorDialog, setErrorDialog, setPage, errorMsg, handlePagination, apiData, onSubmit, setErrorMsg } = useListTableHook(
    apiRoute.gameManagement.listGame, formdata);

    const handleChangePage = (event, newPage) => {    
      let skip = newPage * 20;
      handlePagination(newPage,skip, 20)
    };

const actionButton = [{ name: 'Edit' },{ name: 'View' },{ name: 'Delete' }]
const actionHandler = (name, id) => 
{ 
  switch(name){
    case 'Edit':
    history.push(`/edit-game/${id.id}`)
    break
    case 'View':
    history.push(`/view-game/${id.id}`)
    break
    case 'Delete':
      (async function(){
        try{
          const resp = await del(apiRoute.gameManagement.deleteGame+'/'+id.id)
          setSuccessMsg(resp?.message)
          setSuccessDialog(true)
          apiData()
        }catch(error){
          setErrorMsg(error);
          setErrorDialog(true);
        }
      })()
    break
    default:
    break
  }

}
   

const formik = useFormik({
    initialValues: formdata,
    // validateOnMount:true,
    validationSchema: Yup.object({
      
    }),
    onSubmit:  onSubmit
  })

  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    setPage(0);
    apiData();
  }

  useEffect(() => {
    props.setBreadcrumbItems('Game List', breadcrumbItems);
    apiData();
  }, [])
 
  return (
    <Col xl="12">
    <Card>
       <CardBody>
        <form  onSubmit={formik.handleSubmit}
        >
          <Row>            
            <Col md="6">
              <div className="mb-3 position-relative">
                <Label htmlFor="name">Game Name:</Label>
                <Input
                  type="text" name='name'
                  className="form-control"
                  id="name"
                  placeholder="Enter Game Name"
                  value={formik.values.name}
                  onChange={formik.handleChange}
                />               
              </div>
            </Col>
            <Col md="6">
              <div className="mb-3 position-relative">
                <Label htmlFor="isActiveId">Status:</Label>
                 <select className="form-select form-control" name='status'
                  id="isActiveId"
                  value={formik.values.status}
                  onChange={formik.handleChange}>
                     <option defaultValue hidden>Select a value</option>
                      <option value={'Active'}>Active</option>
                      <option value={'InActive'}>Inactive</option>
                  </select>                 
              </div>
            </Col>           
            </Row>
          
          <div className='d-flex flex-row gap-5 justify-content-center text-center mb-3'>
          <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>
          <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
          </div>
        </form>

        <SharedTable columns={columns} rows={rows} page={page} totalPage={totalPage} handleChangePage={handleChangePage} actionButton={actionButton}
      actionHandler={actionHandler} />
      </CardBody>
    </Card>
    {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false); }} />}
      {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}            
  </Col>
  )
}

export default connect(null, { setBreadcrumbItems })(GameList)