import React, { useEffect } from 'react';
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import SharedTable from 'common/table/SharedTable';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import ErrorPopup from 'common/Popup/ErrorPopup';
import { dateFormate, validFiled } from 'common/SharedFunction';
import apiRoute from '../../common/ApiURL.json';
import { useListTableHook } from 'common/ModuleList and Hooks/ListTableHook';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';

const BonusCodeList = (props) => {

  const history = useHistory();

  const breadcrumbItems = [
    { title: "Arcade", link: "/" },
    { title: "Bonus Management", link: "#" },
    { title: "Bonus Code List", link: "#" },
  ]

  const columns = [
    { id: 'position', label: 'No', format:(value) => value ? value : 'N/A'},
    { id: 'status', label: 'Status', format:(value) => value ? value : 'N/A' },
    { id: 'expiryDate', label: 'Valid Till', format: (value) => dateFormate(value) },
    { id: 'totalUsed', label: 'Total Used', format:(value) => value ? value : 'N/A' },
    { id: 'codeName', label: 'Bonus Code', format:(value) => value ? value : 'N/A' },
    { id: 'bonusAmount', label: 'Amount', format:(value) => value ? value : 'N/A' },
    { id: 'bonusPercent', label: 'Bonus Percent', format:(value) => value ? value : 'N/A' },
    { id: 'createdAt', label: 'Created At', format: (value) => dateFormate(value) },
    { id: 'rcbPercent', label: 'RCB%', format:(value) => value ? value : 'N/A' },
    { id: 'ucbPercent', label: 'UCB%', format:(value) => value ? value : 'N/A' },
    { id: 'instantBonus', label: 'Instant Bonus', format:(value) => value ? value : 'N/A' },
    { id: 'createdBy', label: 'Created By', format:(value) => value ? value : 'N/A' },
    { id: 'bonusCodeType', label: 'Bonus Code Type', format:(value) => value ? value : 'N/A' }

  ];

  const actionButton = [{ name: 'Edit' }];

  const formData = { bonusCodeName: '', bonusPercent: '', createdBy: '' }

  const { rows, totalPage, page, errorDialog, setErrorDialog, setPage, errorMsg, handlePagination, apiData, onSubmit } = useListTableHook(
    apiRoute.bonusManagement.bonusCodeList, formData);

  //Table pagination 
  const handleChangePage = (event, newPage) => {
    let skip = newPage * 20;
    handlePagination(newPage, skip, 20)
  };

  const actionHandler = (name, id) => {
    const paramId = id.id
    if (name === 'Edit') {
      history.push(`/edit-bonus/${paramId}`)
    }
  }


  const formik = useFormik({
    initialValues: formData,
    validateOnMount:true,
    validationSchema: Yup.object({
      bonusCodeName: Yup.string().optional(), 
      bonusPercent: Yup.number().optional().min(0, 'Min value should be 0').max(100, 'Max value should be 100'), 
      createdBy: Yup.string().optional()
    }),
    onSubmit: onSubmit

  });

  // reset form
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
    setPage(0);
    apiData();
  }

  useEffect(() => {
    props.setBreadcrumbItems('Bonus Code List', breadcrumbItems);
    apiData();
  }, [])

  return (
    <Col xl="12">
      <Card>
        <CardBody>
          <form onSubmit={formik.handleSubmit}>
            <Row>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="bonusCodeName">Bonus Code:</Label>
                  <Input
                    type="text" name='bonusCodeName'
                    className="form-control"
                    id="bonusCodeName"
                    placeholder="Enter Bonus Code"
                    value={formik.values.bonusCodeName}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.bonusCodeName ? (
                    <small className="text-danger">{formik.errors.bonusCodeName}</small>
                  ) : null}
                </div>
              </Col>

              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="bonusPercent">Bonus Percent:</Label>
                  <Input
                    type="number" name='bonusPercent'
                    className="form-control"
                    id="bonusPercent"
                    placeholder="Enter Bonus Percent"
                    value={formik.values.bonusPercent}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.bonusPercent ? (
                    <small className="text-danger">{formik.errors.bonusPercent}</small>
                  ) : null}
                </div>
              </Col>
              <Col md="4">
                <div className="mb-3 position-relative">
                  <Label htmlFor="createdBy">Created By:</Label>
                  <Input
                    type="text" name='createdBy'
                    className="form-control"
                    id="createdBy"
                    placeholder="Enter Created By"
                    value={formik.values.createdBy}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.createdBy ? (
                    <small className="text-danger">{formik.errors.createdBy}</small>
                  ) : null}
                </div>
              </Col>

            </Row><div className='d-flex flex-row gap-5 justify-content-center text-center my-3'>
              <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={validFiled(formik.values)}>Submit</Button>
              <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
              {/* <Button type="button" outline color="success" className="waves-effect waves-light">CSV</Button> */}
            </div>
          </form>

          <SharedTable columns={columns} rows={rows} page={page} totalPage={totalPage} handleChangePage={handleChangePage}
          actionButton={actionButton} actionHandler={actionHandler}  />
        </CardBody>
      </Card>
      {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
    </Col>
  )
}

export default connect(null, { setBreadcrumbItems }) (BonusCodeList)