import React from "react"
import ReactDOM from "react-dom"
import App from "./App"
import * as serviceWorker from "./serviceWorker"
import { BrowserRouter } from "react-router-dom"
import { ModuleListContextProvider } from "common/context/moduleListContext"
// import "./i18n"
import { Provider } from "react-redux"

import store from "./store"

const app = (
  <Provider store={store}>
    <ModuleListContextProvider>
    <BrowserRouter>
      <App />
    </BrowserRouter>
    </ModuleListContextProvider>
  </Provider>
)

ReactDOM.render(app, document.getElementById("root"))
serviceWorker.unregister()
