import { useState, useEffect, useRef } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import IndeterminateCheckbox from '../../common/ModuleList and Hooks/IndeterminateCheckbox';
import useCheckList from '../../common/ModuleList and Hooks/CheckListHook';
import { useParams, useHistory } from 'react-router-dom/cjs/react-router-dom';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { get, put } from "../../helpers/api_helper"
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup';
import apiRoute from '../../common/ApiURL.json';


const EditUser = (props) => {
    const { id } = useParams()
    const history = useHistory()
    const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "User Management", link: "#" },
        { title: "Edit User", link: "#" },
    ]
    const [formData, setFormData] = useState({
        name: '',
        userName: '',
        mobile: '',
        emailId: '',
        reportingTo: '',
        status: '',
        role: '',
    })


    // Dailog variable
    const [successDialog, setSuccessDialog] = useState(false);
    const [successMsg, setSuccessMsg] = useState('');
    const [errorDialog, setErrorDialog] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');
    const { checkboxData, handleChangeParent, handleChangeChild, setCheckboxData } = useCheckList([]);
    const checkboxRef = useRef('');



    const formik = useFormik({
        enableReinitialize: true,
        initialValues: formData,
        validationSchema: Yup.object({
            name: Yup.string().required('Name required'),
            userName: Yup.string().required('Username required').max(20, 'Max 20 digit required').min(3, 'Min 3 digit required'),
            mobile: Yup.string().required('Mobile No required').max(10, 'Max 10 digit required').min(10, 'Min 10 digit required'),
            emailId: Yup.string().email('Enter a valid Email').required('Email required'),
            reportingTo: Yup.string().required('Reporting to required'),
            status: Yup.string().required('Player Status required'),
            role: Yup.string().required('Level required'),
        }),
        onSubmit: async values => {
           try {
            const newObject = { 
                name: values.name,
                userName: values.userName,
                mobile: values.mobile,
                emailId: values.emailId,
                reportingTo: values.reportingTo,
                status: values.status,
                role: values.role};
                const resp = await put(`${apiRoute.userManagement.updateUser}/${id}`, {...newObject, modules: checkboxData })
                setSuccessMsg(resp?.message)
                setSuccessDialog(true)
            } catch (error) {
                setErrorMsg(error);
                setErrorDialog(true);
            }
        },
    });

    async function apiData() {
        try {
            const resp = await get(apiRoute.userManagement.listUser, { params: { id } })
            setFormData({ ...resp.data });
            setCheckboxData([...resp?.data?.modules ])
            checkboxRef.current = [...resp?.data?.modules ]
        } catch (error) {
            setErrorMsg(error);
            setErrorDialog(true);
        }
    }

    useEffect(() => {
        props.setBreadcrumbItems('Edit User', breadcrumbItems);
        apiData();
    }, [])

    const formReset = (event) => {
        event.preventDefault();
        history.goBack();
    }

    return (
        <Col xl="12">
            <Card>
                <CardBody>
                    <form onSubmit={formik.handleSubmit}
                    >
                        <Row>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip01">Name:</Label>
                                    <Input
                                        type="text" name='name'
                                        className="form-control"
                                        id="validationTooltip01"
                                        placeholder="Enter Name"
                                        value={formik.values.name}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.name ? (
                                        <small className="text-danger">{formik.errors.name}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip02">Username:</Label>
                                    <Input
                                        type="text" name='userName'
                                        className="form-control"
                                        id="validationTooltip02"
                                        placeholder="Enter Username"
                                        value={formik.values.userName}
                                        onChange={formik.handleChange} readOnly
                                    />
                                    {formik.errors.userName ? (
                                        <small className="text-danger">{formik.errors.userName}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="mobile">Telephone:</Label>

                                    <PhoneInput
                     disableDialCodeAndPrefix={true}
                     disableFormatting={true}
                     inputClassName='form-control'
                         defaultCountry="in" name='mobile'
                        id="mobile"
                        placeholder="Enter Mobile"
                        value={formik.values.mobile}
                      onChange={(data, meta) => {
                        formik.setFieldValue('mobile',meta.inputValue);
                      }}
                      />
                                    {formik.errors.mobile ? (
                                        <small className="text-danger">{formik.errors.mobile}</small>
                                    ) : null}
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip03">Email:</Label>
                                    <Input
                                        type="email" name='emailId'
                                        className="form-control"
                                        id="validationTooltip03"
                                        placeholder="Enter Email"
                                        value={formik.values.emailId}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.emailId ? (
                                        <small className="text-danger">{formik.errors.emailId}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Reporting To:</Label>
                                    <Input
                                        type="text" name='reportingTo'
                                        className="form-control"
                                        id="validationTooltip04"
                                        placeholder="Enter Reporting To"
                                        value={formik.values.reportingTo}
                                        onChange={formik.handleChange}
                                    />
                                    {formik.errors.reportingTo ? (
                                        <small className="text-danger">{formik.errors.reportingTo}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Player Status:</Label>
                                    <select className="form-select form-control"
                                        value={formik.values.status}
                                        name='status'
                                        onChange={formik.handleChange}>
                                        <option defaultValue hidden>Select Player Status</option>
                                        <option>Active</option>
                                        <option>Blocked</option>
                                    </select>
                                    {formik.errors.selectedValue ? (
                                        <small className="text-danger">{formik.errors.status}</small>
                                    ) : null}
                                </div>
                            </Col>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Level:</Label>
                                    <select className="form-select form-control"
                                        value={formik.values.role}
                                        name='role'
                                        onChange={formik.handleChange}>
                                        <option defaultValue hidden>Select a Level</option>
                                        <option>Director</option>
                                        <option>General Manager</option>
                                        <option>Senior Delivery Manager</option>
                                        <option>Team Lead</option>
                                        <option>Senior Executive</option>
                                        <option>Executive</option>
                                    </select>
                                    {formik.errors.level ? (
                                        <small className="text-danger">{formik.errors.role}</small>
                                    ) : null}
                                </div>
                            </Col>
                        </Row>
                        <div className="container-fluid text-center bg-dark text-white fs-3 p-2 my-10"><span> Modules / Sub-Modules </span></div>

                        {checkboxData?.map((checkbox, index) => (
                            <IndeterminateCheckbox
                                key={index}
                                index={index}
                                label={checkbox.name}
                                checked={checkbox.allTicked}
                                onChange={handleChangeParent}
                                children={checkbox.subModules}
                                childrenHandle={(childIndex) => handleChangeChild(index, childIndex)}
                            />
                        ))}

                        <div className='d-flex flex-row gap-5 justify-content-center text-center mt-5'>
                            <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>
                            <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Back</Button>
                        </div>
                    </form>
                </CardBody>
            </Card>
            {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false);
            history.push(`/list-user`) }} />}
            {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
        </Col>
    )
}

export default connect(null, { setBreadcrumbItems })(EditUser)