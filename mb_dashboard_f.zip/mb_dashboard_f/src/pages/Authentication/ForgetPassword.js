import PropTypes from 'prop-types'
import React from "react"
import { Row, Col, Alert, Card, CardBody, Container } from "reactstrap"
import { useFormik } from 'formik'
import * as Yup from "yup";

// Redux
import { connect } from "react-redux"
import { withRouter, Link } from "react-router-dom"

// action
import { userForgetPassword } from "../../store/actions"

// import images
import logoLightPng from "../../assets/images/Arcade.png"
import logoDark from "../../assets/images/Arcade.png"

const ForgetPasswordPage = props => {

  const formData = {
    emailId: '',
}
const formik = useFormik({
  initialValues: formData,
  validationSchema: Yup.object({
    emailId: Yup.string().email('Enter a valid Email').required('Email is required'),      
        }),
  onSubmit: async values => {
    console.log('working')
  },
});

  return (
    <React.Fragment>
      <div className="account-pages my-5 pt-sm-5">
        <Container>
          <Row className="justify-content-center">
            <Col md={8} lg={6} xl={5}>
              <Card className="overflow-hidden">
                <CardBody className="pt-0">
                  <h3 className="text-center mt-5 mb-4">
                    <Link to="/" className="d-block auth-logo">
                      <img src={logoDark} alt="" height="30" className="auth-logo-dark" />
                      <img src={logoLightPng} alt="" height="30" className="auth-logo-light" />
                    </Link>
                  </h3>
                  <div className="p-3">
                    <h4 className="text-muted font-size-18 mb-3 text-center">Reset Password</h4>
                    <div className="alert alert-info" role="alert">
                      Enter your Email and instructions will be sent to you!
                    </div>
                    
                    <form
                      className="form-horizontal mt-4"
                     onSubmit={formik.handleSubmit}
                    >
                      <div className="mb-3">
                        <input
                          name="emailId"
                          label="Email"
                          className="form-control"
                          placeholder="Enter email"
                          type="email"
                          value={formik.values.emailId}
                          onChange={formik.handleChange}
                          required
                        />
                        {formik.errors.emailId ? (
                                        <small className="text-danger">{formik.errors.emailId}</small>
                                    ) : null}
                      </div>
                      <Row className="mb-3">
                        <Col className="text-end">
                          <button
                            className="btn btn-primary w-md waves-effect waves-light"
                            type="submit"
                          >
                            Reset
                          </button>
                        </Col>
                      </Row>
                    </form>
                  </div>
                </CardBody>
              </Card>
              <div className="mt-5 text-center">
                <p>
                  Remember It ?{" "}
                  <Link to="login" className="text-primary">
                    Sign In Here
                  </Link>{" "}
                </p>
                <p>
                  © {new Date().getFullYear()} Arcade <span className="d-none d-sm-inline-block"> - Crafted with <i className="mdi mdi-heart text-danger"></i> Taab.</span>
                </p>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    </React.Fragment>
  )
}

ForgetPasswordPage.propTypes = {
  forgetError: PropTypes.any,
  forgetSuccessMsg: PropTypes.any,
  history: PropTypes.object,
  userForgetPassword: PropTypes.func
}

const mapStatetoProps = state => {
  const { forgetError, forgetSuccessMsg } = state.ForgetPassword
  return { forgetError, forgetSuccessMsg }
}

export default withRouter(
  connect(mapStatetoProps, { userForgetPassword })(ForgetPasswordPage)
)
