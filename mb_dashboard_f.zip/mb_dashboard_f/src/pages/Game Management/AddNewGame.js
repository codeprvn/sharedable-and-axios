import { useState, useEffect } from 'react'
import { useFormik } from 'formik'
import * as Yup from "yup";
import {  Row,  Col,  Card,  CardBody,  Button,  Label,  Input,} from "reactstrap";
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import ErrorPopup from 'common/Popup/ErrorPopup';
import SuccessPoup from 'common/Popup/SuccessPoup'; 
import apiRoute from '../../common/ApiURL.json';
import { post } from 'helpers/api_helper';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';

const AddNewGame = (props) => {
  const {push} = useHistory();
    const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "Game Management", link: "#" },
        { title: "Add New Game", link: "#" },
      ]
   
  useEffect(() => {
    props.setBreadcrumbItems('Add New Game', breadcrumbItems)
  })

  const formData = {
    name:'',
    type:'',
    status:'',
    imageUrl:'',
    gameLink:'',
    token:'',
    key:''
};

 // Dailog variable
 const [successDialog, setSuccessDialog ] = useState(false);
 const [successMsg, setSuccessMsg] = useState('');
 const [errorDialog, setErrorDialog ] = useState(false);
 const [errorMsg, setErrorMsg] = useState('');

  const formik = useFormik({
    initialValues: formData,
    validationSchema: Yup.object({
      name: Yup.string().required('Game Name is required'),
      type: Yup.string().required('Game Type is required'),
      status: Yup.string().required('Status is required'),
      imageUrl:Yup.string().required('Image Url is required'),
    gameLink:Yup.string().required('Game Link is required'),
    }),
    onSubmit: async values => {
      try {
        const resp = await post(apiRoute.gameManagement.createGame, { ...values})
        setSuccessMsg(resp?.message);
        setSuccessDialog(true);       

    } catch (error) {
        setErrorMsg(error);
        setErrorDialog(true);
    } 
    },
  });
  
  const formReset = (event) => {
    event.preventDefault();
    formik.resetForm();
  }
 
  return (
    <Col xl="12">
    <Card>
      <CardBody>
        <form  onSubmit={formik.handleSubmit}
        >
          <Row>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="name">Game Name:</Label>
                <Input
                  type="text" name='name'
                  className="form-control"
                  id="name"
                  placeholder="Enter Game Name"
                  value={formik.values.name}
                  onChange={formik.handleChange}
                />
                {formik.errors.name ? (
              <small className="text-danger">{formik.errors.name}</small>
            ) : null}
              </div>
            </Col>
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="gameTypeId">Game Type:</Label>
                <select className="form-select form-control"
                        value={formik.values.type}
                        name='type' id='gameTypeId'
                        onChange={formik.handleChange}>
                       <option defaultValue hidden>Select a Value</option>
                      <option value={'Casino Games'}>Casino Games</option>
                      <option value={'House of Cards'}>House of Cards</option>
                      <option value={'Casual Games'}>Casual Games</option>
                    </select>
                    {formik.errors.type ? (
              <small className="text-danger">{formik.errors.type}</small>
            ) : null}
              </div>
            </Col>
            
            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="statusId">Status:</Label>
                 <select className="form-select form-control" name='status'
                  id="statusId"
                  value={formik.values.status}
                  onChange={formik.handleChange}>
                     <option defaultValue hidden>Select a value</option>
                      <option value={'Active'}>Active</option>
                      <option value={'InActive'}>Inactive</option>
                  </select> 
                  {formik.errors.status ? (
              <small className="text-danger">{formik.errors.status}</small>
            ) : null}                
              </div>
            </Col>

             <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="imageUrl">Image Url:</Label>
                <Input
                  type="text" name='imageUrl'
                  className="form-control"
                  id="imageUrl"
                  placeholder="Enter Image Url"
                  value={formik.values.imageUrl}
                  onChange={formik.handleChange}
                />
                {formik.errors.imageUrl ? (
              <small className="text-danger">{formik.errors.imageUrl}</small>
            ) : null}
              </div>
            </Col>       

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="gameLink">Game Link:</Label>
                <Input
                  type="text" name='gameLink'
                  className="form-control"
                  id="gameLink"
                  placeholder="Enter Game link"
                  value={formik.values.gameLink}
                  onChange={formik.handleChange}
                />
                {formik.errors.gameLink ? (
              <small className="text-danger">{formik.errors.gameLink}</small>
            ) : null}
              </div>
            </Col>

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="token">Token:</Label>
                <Input
                  type="text" name='token'
                  className="form-control"
                  id="token"
                  placeholder="Enter token"
                  value={formik.values.token}
                  onChange={formik.handleChange}
                />
                {formik.errors.token ? (
              <small className="text-danger">{formik.errors.token}</small>
            ) : null}
              </div>
            </Col> 

            <Col md="4">
              <div className="mb-3 position-relative">
                <Label htmlFor="token">Key:</Label>
                <Input
                  type="text" name='key'
                  className="form-control"
                  id="key"
                  placeholder="Enter Key"
                  value={formik.values.key}
                  onChange={formik.handleChange}
                />
                {formik.errors.key ? (
              <small className="text-danger">{formik.errors.key}</small>
            ) : null}
              </div>
            </Col> 

            </Row>

          <div className='d-flex flex-row gap-5 justify-content-center text-center mt-3'>
          <Button type="submit" outline color="primary" className="waves-effect waves-light" disabled={!formik.isValid}>Submit</Button>
          <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Reset</Button>
          </div>
        </form>
      </CardBody>
    </Card>
    {successDialog && <SuccessPoup successMsg={successMsg}   onConfirm={() => { setSuccessDialog(false); push('/game-list') }} />}
            {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}           
  </Col>
  )
}

export default connect(null, { setBreadcrumbItems })(AddNewGame);