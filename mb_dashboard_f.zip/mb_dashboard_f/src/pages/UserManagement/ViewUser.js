import { useState, useEffect } from 'react'
import { useFormik } from 'formik'
import { Row, Col, Card, CardBody, Button, Label, Input, } from "reactstrap";
import IndeterminateCheckbox from '../../common/ModuleList and Hooks/IndeterminateCheckbox';
import useCheckList from '../../common/ModuleList and Hooks/CheckListHook';
import { useParams, useHistory } from 'react-router-dom/cjs/react-router-dom';
import { setBreadcrumbItems } from "../../store/actions";
import { connect } from "react-redux";
import { get } from "../../helpers/api_helper"
import ErrorPopup from 'common/Popup/ErrorPopup';
import apiRoute from '../../common/ApiURL.json';


const ViewUser = (props) => {
    const history = useHistory();
    const breadcrumbItems = [
        { title: "Arcade", link: "/" },
        { title: "User Management", link: "#" },
        { title: "View User", link: "#" },
    ]

    const [formData, setFormData] = useState({
        name: '',
        userName: '',
        mobile: '',
        emailId: '',
        reportingTo: '',
        status: '',
        role: '',
    });

    const { id } = useParams()
    // Dailog variable
    const [errorDialog, setErrorDialog] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');
    const { checkboxData, handleChangeParent, handleChangeChild, setCheckboxData } = useCheckList([]);



    const formik = useFormik({
        enableReinitialize: true,
        initialValues: formData,        
    });

    const formReset = (event) => {
        event.preventDefault();
        formik.resetForm();
        history.goBack();
    }

    async function apiData() {
        try {
            const resp = await get(apiRoute.userManagement.listUser, { params: { id } })
            setFormData({ ...resp.data });
            setCheckboxData([...resp?.data?.modules ]);
        } catch (error) {
            setErrorMsg(error);
            setErrorDialog(true);
        }
    }

    useEffect(() => {
        props.setBreadcrumbItems('View User', breadcrumbItems)
        apiData();
    }, [])

    return (
        <Col xl="12">
            <Card>
                <CardBody>
                    <form onSubmit={formik.handleSubmit}
                    >
                        <Row>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip01">Name:</Label>
                                    <Input
                                        type="text" name='name'
                                        className="form-control"
                                        id="validationTooltip01"
                                        placeholder="Enter Name"
                                        value={formik.values.name}
                                        onChange={formik.handleChange} readOnly
                                    />
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip02">Username:</Label>
                                    <Input
                                        type="text" name='userName'
                                        className="form-control"
                                        id="validationTooltip02"
                                        placeholder="Enter Username"
                                        value={formik.values.userName}
                                        onChange={formik.handleChange} readOnly
                                    />
                                </div>
                            </Col>
                            <Col md="4">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltipUsername">Telephone:</Label>

                                    <Input
                                        type="text" name='mobile'
                                        className="form-control"
                                        id="validationTooltipUsername"
                                        placeholder="Enter MobileNo"
                                        value={formik.values.mobile}
                                        onChange={formik.handleChange} readOnly
                                    />
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip03">Email:</Label>
                                    <Input
                                        type="email" name='emailId'
                                        className="form-control"
                                        id="validationTooltip03"
                                        placeholder="Enter Email"
                                        value={formik.values.emailId}
                                        onChange={formik.handleChange} readOnly
                                    />
                                </div>
                            </Col>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Reporting To:</Label>
                                    <Input
                                        type="text" name='reportingTo'
                                        className="form-control"
                                        id="validationTooltip04"
                                        placeholder="Enter Reportingto"
                                        value={formik.values.reportingTo}
                                        onChange={formik.handleChange} readOnly
                                    />
                                </div>
                            </Col>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Player Status:</Label>
                                    <select className="form-select form-control"
                                        value={formik.values.status}
                                        name='status'
                                        onChange={formik.handleChange} disabled>
                                        <option defaultValue hidden>Select Player Status</option>
                                        <option>Active</option>
                                        <option>Blocked</option>
                                    </select>
                                </div>
                            </Col>
                            <Col md="6">
                                <div className="mb-3 position-relative">
                                    <Label htmlFor="validationTooltip04">Level:</Label>
                                    <select className="form-select form-control"
                                        value={formik.values.role}
                                        name='role'
                                        onChange={formik.handleChange} disabled>
                                        <option defaultValue hidden>Select a Level</option>
                                        <option>Director</option>
                                        <option>General Manager</option>
                                        <option>Senior Delivery Manager</option>
                                        <option>Team Lead</option>
                                        <option>Senior Executive</option>
                                        <option>Executive</option>
                                    </select>
                                </div>
                            </Col>
                        </Row>
                        <div className="container-fluid text-center bg-dark text-white fs-3 p-2 my-10"><span> Modules / Sub-Modules </span></div>

                        {checkboxData?.map((checkbox, index) => (
                            <IndeterminateCheckbox
                                key={index}
                                index={index}
                                label={checkbox.name}
                                checked={checkbox.allTicked}
                                onChange={handleChangeParent}
                                children={checkbox.subModules}
                                childrenHandle={(childIndex) => handleChangeChild(index, childIndex)}
                                isDisabled={true}
                            />
                        ))}

                        <div className='d-flex flex-row gap-5 justify-content-center text-center mt-5'>
                            <Button type="button" outline color="danger" onClick={formReset} className="waves-effect waves-light">Back</Button>
                        </div>
                    </form>
                </CardBody>
            </Card>
            {errorDialog && <ErrorPopup errorMsg={errorMsg} onConfirm={() => { setErrorDialog(false) }} />}
        </Col>
    )
}

export default connect(null, { setBreadcrumbItems })(ViewUser)